"use strict";(self.webpackChunkopenegiz_openegiz_app=self.webpackChunkopenegiz_openegiz_app||[]).push([[187],{206:(e,t,n)=>{n.r(t),n.d(t,{App:()=>Er,default:()=>wr});var a=n(959),r=n.n(a),o=n(806),i=n(531),l=n(89),s=n(781),c=n(7);function d(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function p(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){d(o,a,r,i,l,"next",e)}function l(e){d(o,a,r,i,l,"throw",e)}i(void 0)}))}}var u=function(e){return e.VIEWER="Viewer",e.ADMIN="Admin",e.EDITOR="Editor",e}({});const m=()=>p((function*(){try{const e=yield(0,i.getBackendSrv)().get("/api/org"),t=(yield(0,i.getBackendSrv)().get("/api/user/orgs")).find((t=>t.orgId===e.id));return t.role?t.role:"Viewer"}catch(e){return console.error("Error fetching user role:",e),"Viewer"}}))(),g=()=>p((function*(){const e=yield m();return f(e)}))(),f=e=>"Admin"===e||"Editor"===e,y=(e,t)=>e===t||"Viewer"===t||"Editor"===t&&"Admin"===e,h=JSON.parse('{"name":"example-connection-123","connectionType":"amqp-10","connectionStatus":"open","failoverEnabled":true,"uri":"amqps://user:password@hono.eclipse.org:5671","sources":[{"addresses":["telemetry/FOO"],"authorizationContext":["nginx:ditto"]}],"targets":[{"address":"events/twin","topics":["_/_/things/twin/events"],"authorizationContext":["nginx:ditto"]}]}');var b=function(e){return e.MQTT5="MQTT5",e.KAFKA="Kafka",e.OTHERS="Others",e}({});const v="Blank spaces and uppercase letters are not allowed",E="If you have defined a custom Payload Mapping, please ensure you select its ID below.",w=[{label:b.MQTT5,value:b.MQTT5},{label:b.KAFKA,value:b.KAFKA},{label:b.OTHERS,value:b.OTHERS}],x=[{label:"plain",value:0},{label:"scram-sha-256",value:1},{label:"scram-sha-512",value:2}],$={label:"1",value:1},O={label:"Ditto protocol",value:"Ditto"},C={id:"",code:"function mapToDittoProtocolMsg(headers, textPayload, bytePayload, contentType) {\r\n\tconst jsonData = JSON.parse(textPayload);\r\n\tconst namespace = 'test';\r\n\tconst name = jsonData.id;\r\n\tconst value = jsonData.value;\r\n\theaders = Object.assign(headers, { 'Content-Type': 'application/merge-patch+json' });\r\n\r\n\tconst feature = {\r\n\t\thumidity: {\r\n\t\t\tproperties: {\r\n\t\t\t\tvalue: value\r\n\t\t\t}\r\n\t\t}\r\n\t};\r\n\t\r\n\treturn Ditto.buildDittoProtocolMsg(\r\n\t\tnamespace,\r\n\t\tname,\r\n\t\t'things',\r\n\t\t'twin',\r\n\t\t'commands',\r\n\t\t'merge',\r\n\t\t'/features',\r\n\t\theaders,\r\n\t\tfeature\r\n\t);\r\n}"},S={addresses:"",authorizationContext:"nginx:ditto",qos:$,payloadMapping:O,others:""},k={address:"",topics:"_/_/things/twin/events,_/_/things/live/messages",authorizationContext:"nginx:ditto",qos:$,payloadMapping:O,others:""},T={bootstrapServers:"",saslMechanism:{label:"plain",value:0}},P={id:"",uri:"",ssl:!1,hasAuth:!1,initStatus:!0,payloadMapping:[],sources:[],targets:[],kafkaData:T,sslData:{ca:"",cert:"",key:""}},N="ssl",j="initStatus",I="payloadMapping",D="sources",A="targets",R="kafkaData",L="sslData",M="others",z="qos",B="saslMechanism",F="ca",q="cert",G="key";function U(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function _(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){U(e,t,n[t])}))}return e}function H(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}var W=n(269);function J(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function K(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){J(o,a,r,i,l,"next",e)}function l(e){J(o,a,r,i,l,"throw",e)}i(void 0)}))}}function V(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}const Y="openegiz-openegiz-app",Q=`api/plugin-proxy/${Y}/agents`,X=`api/plugin-proxy/${Y}/extended/api`,Z=`api/plugin-proxy/${Y}/ditto/api/2`,ee=`api/plugin-proxy/${Y}/dittodevops/api/2`;function te(e,t){return K((function*(){const n=(0,i.getBackendSrv)().fetch(function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){V(e,t,n[t])}))}return e}({url:e,showErrorAlert:!1},t));return(yield(0,W.lastValueFrom)(n)).data}))()}function ne(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function ae(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){ne(o,a,r,i,l,"next",e)}function l(e){ne(o,a,r,i,l,"throw",e)}i(void 0)}))}}const re=e=>ae((function*(){return yield te(`${ee}/connections/${e}/command`,{method:"POST",headers:{"Content-Type":"text/plain"},data:"connectivity.commands:closeConnection"})}))(),oe=e=>ae((function*(){return yield te(`${ee}/connections`,{method:"POST",data:e})}))(),ie=e=>ae((function*(){return yield te(`${ee}/connections/${e}/logs`,{method:"GET"})}))(),le=e=>ae((function*(){return yield te(`${ee}/connections/${e}/metrics`,{method:"GET"})}))(),se=e=>ae((function*(){return yield te(`${ee}/connections/${e}/status`,{method:"GET"})}))(),ce=e=>ae((function*(){return yield te(`${ee}/connections/${e}/command`,{method:"POST",headers:{"Content-Type":"text/plain"},data:"connectivity.commands:openConnection"})}))(),de=e=>ae((function*(){return yield te(`${ee}/connections/${e}/command`,{method:"POST",headers:{"Content-Type":"text/plain"},data:"connectivity.commands:resetConnectionLogs"})}))(),pe=e=>ae((function*(){return yield te(`${ee}/connections/${e}/command`,{method:"POST",headers:{"Content-Type":"text/plain"},data:"connectivity.commands:resetConnectionMetrics"})}))();function ue(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function me(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){ue(e,t,n[t])}))}return e}function ge(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const fe=e=>e.split(",").map((e=>e.trim())),ye=e=>e.includes(" ")||e.toLowerCase()!==e,he=({payloadMapping:e,sources:t,targets:n,onChange:o,onBlur:i,onRemove:l})=>{if(0===e.length)return r().createElement("div",null);const s=e=>{if(!e||e.includes("\n"))return e||"";let t=0;return e.replace(/[{};]/g,(e=>"{"===e?`{\n${"\t".repeat(++t)}`:"}"===e?`\n${"\t".repeat(Math.max(0,--t))}}`:`;\n${"\t".repeat(t)}`))};return r().createElement(a.Fragment,null,r().createElement(c.Alert,{title:"Warning",severity:"warning",style:{marginTop:"20px"}},r().createElement("div",null,"The mapping function must always have the name mapToDittoProtocolMsg and the specified parameters. In addition, it must return an object or a list of objects built with Ditto.buildDittoProtocolMsg. It uses the Rhino JavaScript engine, double quotes are not allowed and semicolons are mandatory.")),r().createElement(c.Alert,{title:"Info",severity:"info"},r().createElement("div",null,'The code shown is an example for a mapper that updates the “humidity” feature for digital twins of the namespace "test". For example, a message { "id": "twin", "value": 5 } would update the “humidity” feature of the digital twin test:twin to 2.')),e.map(((e,d)=>{const p=t.some((t=>{var n;return(null===(n=t.payloadMapping)||void 0===n?void 0:n.value)===e.id}))||n.some((t=>{var n;return(null===(n=t.payloadMapping)||void 0===n?void 0:n.value)===e.id}));return r().createElement(a.Fragment,{key:d},r().createElement(c.Field,{label:"ID",required:!0,description:"A unique identifier for the payload mapping",invalid:ye(e.id),error:ye(e.id)?v:"",disabled:p},r().createElement(c.Input,{id:"id",name:"id",required:!0,type:"text",value:e.id,onChange:e=>o(e,I,d),disabled:p})),r().createElement(c.Field,{label:"JavaScript code",description:"JavaScript function that will process messages received by the connection to update at least one digital twin.",style:{marginTop:"10px"}},r().createElement(c.CodeEditor,{value:s(e.code),language:"javascript",height:600,onBlur:e=>i(e,d),showLineNumbers:!0,showMiniMap:!1,monacoOptions:{formatOnPaste:!0,formatOnType:!0},onEditorDidMount:(e,t)=>{e.getAction("editor.action.formatDocument").run()}})),r().createElement("div",{style:{display:"flex",justifyContent:"flex-end"}},r().createElement(c.Button,{variant:"destructive",disabled:p,icon:"trash-alt",onClick:()=>l(I,d)},"Delete")))})))},be=({sources:e,qosOptions:t,pmOptions:n,onInputChange:o,onSelectChange:i,onBlurOthers:l,onRemove:s})=>r().createElement(a.Fragment,null,e.map(((e,d)=>r().createElement(a.Fragment,{key:d},r().createElement(c.Field,{label:"Adresses",required:!0,description:"Topics to subscribe to. If more than one, separate them with commas."},r().createElement(c.Input,{name:"addresses",required:!0,type:"text",value:e.addresses,onChange:e=>o(e,D,d)})),r().createElement(c.Field,{label:"QoS",required:!0,description:"Messages are consumed more or less strictly depending on the configured qos (Quality of Service) value of the source"},r().createElement(c.Select,{options:t,value:e.qos,onChange:e=>i(e,D,z,d)})),r().createElement(c.Alert,{title:"Warning",severity:"warning",style:{marginTop:"20px"}},r().createElement("div",null,E)),r().createElement(c.Field,{label:"Payload mapping",description:"Mapper that will process the messages. Default is Ditto protocol."},r().createElement(c.Select,{options:n,value:e.payloadMapping,onChange:e=>i(e,D,I,d)})),r().createElement(c.Field,{label:"Other configurations",description:"Add any other Eclipse Ditto settings you need in this section. This will be mixed in with the rest of the data"},r().createElement(c.CodeEditor,{value:e.others,language:"json",height:100,onBlur:e=>l(e,d,D),showLineNumbers:!0,showMiniMap:!1,monacoOptions:{formatOnPaste:!0,formatOnType:!0}})),r().createElement("div",{style:{display:"flex",justifyContent:"flex-end"}},r().createElement(c.Button,{variant:"destructive",icon:"trash-alt",onClick:()=>s(D,d)},"Delete")))))),ve=({targets:e,protocol:t,qosOptions:n,pmOptions:o,onInputChange:i,onSelectChange:l,onBlurOthers:s,onRemove:d})=>r().createElement(a.Fragment,null,e.map(((e,p)=>r().createElement(a.Fragment,{key:p},r().createElement(c.Field,{label:"Address",required:!0,description:"Topic to publish events and messages to"},r().createElement(c.Input,{name:"address",required:!0,type:"text",value:e.address,onChange:e=>i(e,A,p)})),r().createElement(c.Field,{label:"Topics",required:!0,description:"List of strings, each list entry representing a subscription of Ditto protocol topics"},r().createElement(c.Input,{name:"topics",required:!0,type:"text",value:e.topics,onChange:e=>i(e,A,p)})),r().createElement(c.Field,{label:"QoS",hidden:t!==b.MQTT5,required:t===b.MQTT5,description:"Messages are consumed more or less strictly depending on the configured qos (Quality of Service) value of the source"},r().createElement(c.Select,{options:n,value:e.qos,onChange:e=>l(e,A,z,p)})),r().createElement(c.Alert,{title:"Warning",severity:"warning",style:{marginTop:"20px"}},r().createElement("div",null,E)),r().createElement(c.Field,{label:"Payload mapping",description:"Mapper that will process the messages. Default is Ditto protocol."},r().createElement(c.Select,{options:o,value:e.payloadMapping,onChange:e=>l(e,A,I,p)})),r().createElement(c.Field,{label:"Other configurations",description:"Add any other Eclipse Ditto settings you need in this section. This will be mixed in with the rest of the data."},r().createElement(c.CodeEditor,{value:e.others,language:"json",height:100,onBlur:e=>s(e,p,A),showLineNumbers:!0,showMiniMap:!1,monacoOptions:{formatOnPaste:!0,formatOnType:!0}})),r().createElement("div",{style:{display:"flex",justifyContent:"flex-end"}},r().createElement(c.Button,{variant:"destructive",icon:"trash-alt",onClick:()=>d(A,p)},"Delete")))))),Ee=({kafkaData:e,onInputChange:t,onSelectChange:n})=>r().createElement("div",null,r().createElement(c.Field,{label:"Bootstraps servers",required:!0,description:"Contains a comma separated list of Kafka bootstrap servers to use for connecting to (in addition to the still required connection uri)"},r().createElement(c.Input,{name:"bootstrapServers",required:!0,type:"text",value:e.bootstrapServers,onChange:e=>t(e,R)})),r().createElement(c.Field,{label:"SASL mechanism",required:!0,description:"Required if connection uri contains username/password. Choose one of the following SASL mechanisms to use for authentication at Kafka"},r().createElement(c.Select,{options:x,value:e.saslMechanism,onChange:e=>n(e,R,B)}))),we=({sslData:e,protocol:t,onBlur:n})=>r().createElement("div",null,r().createElement(c.Field,{label:"CA",description:"A string of trusted certificates as PEM-encoded DER. Concatenate multiple certificates as strings to trust all of them. Omit to trust popular certificate authorities."},r().createElement(c.CodeEditor,{value:e.ca,language:"txt",height:100,onBlur:e=>n(e,L,F),showLineNumbers:!0,showMiniMap:!1,monacoOptions:{formatOnPaste:!0,formatOnType:!0}})),r().createElement(c.Field,{label:"Client cert",hidden:t!==b.MQTT5,description:"The client certificate as PEM-encoded DER"},r().createElement(c.CodeEditor,{value:e.cert,language:"txt",height:100,onBlur:e=>n(e,L,q),showLineNumbers:!0,showMiniMap:!1,monacoOptions:{formatOnPaste:!0,formatOnType:!0}})),r().createElement(c.Field,{label:"Client key",hidden:t!==b.MQTT5,description:"The client private key for Ditto as PEM-encoded PKCS8 specified by RFC-7468; the PEM preamble must be -----BEGIN PRIVATE KEY-----"},r().createElement(c.CodeEditor,{value:e.key,language:"txt",height:100,onBlur:e=>n(e,L,G),showLineNumbers:!0,showMiniMap:!1,monacoOptions:{formatOnPaste:!0,formatOnType:!0}}))),xe=e=>e.includes(" ")||e.toLowerCase()!==e,$e=({connectionData:e,handlers:t,protocol:n,isEditMode:a})=>{const o=[O].concat(e.payloadMapping.map((e=>({label:e.id,value:e.id})))),i=Array.from({length:n===b.MQTT5?3:2},((e,t)=>({value:t,label:t.toLocaleString()})));return r().createElement("div",{style:{minHeight:"100%",width:"100%"}},r().createElement("div",{style:{marginBottom:"40px"}},r().createElement("h4",null," General information "),r().createElement("hr",{style:{marginBottom:"20px"}}),r().createElement(c.Field,{label:"Identifier",required:!0,description:"A unique identifier for the connection",invalid:xe(e.id),error:xe(e.id)?v:""},r().createElement(c.Input,{id:"id",name:"id",required:!0,value:e.id,onChange:t.handleOnChangeInput,disabled:a})),r().createElement(c.Field,{label:"Status",description:"Initial connection status"},r().createElement("div",{style:{display:"flex",alignItems:"center"}},r().createElement(c.InlineLabel,{width:5.1,transparent:!0,style:{marginRight:"10px"}},e.initStatus?"Open":"Close"),r().createElement(c.Switch,{value:e.initStatus,name:"initStatus",onClick:e=>t.handleOnChangeSwitch(e,j)}))),r().createElement(c.Field,{label:"Host URI",required:!0,description:"Host address and port of the broker"},r().createElement("div",{style:{display:"flex",alignItems:"center"}},r().createElement(c.InlineLabel,{transparent:!0,width:4,style:{marginRight:"10px"}},e.ssl?"ssl://":"tcp://"),r().createElement(c.Input,{id:"uri",name:"uri",required:!0,type:"text",value:e.uri,onChange:t.handleOnChangeInput}))),r().createElement(c.Field,{label:"Authentication",description:"Enable username and password authentication"},r().createElement("div",{style:{display:"flex",alignItems:"center"}},r().createElement(c.InlineLabel,{transparent:!0,width:7,style:{marginRight:"10px"}},e.hasAuth?"Enabled":"Disabled"),r().createElement(c.Switch,{value:e.hasAuth,onClick:e=>t.handleOnChangeSwitch(e,"hasAuth")}))),e.hasAuth&&r().createElement("div",{style:{display:"flex",gap:"10px",marginBottom:"10px"}},r().createElement(c.Field,{label:"Username",style:{flex:1}},r().createElement(c.Input,{id:"username",name:"username",value:e.username||"",onChange:t.handleOnChangeInput})),r().createElement(c.Field,{label:"Password",style:{flex:1}},r().createElement(c.Input,{id:"password",name:"password",type:"password",value:e.password||"",onChange:t.handleOnChangeInput}))),n===b.KAFKA&&r().createElement(Ee,{kafkaData:e.kafkaData,onInputChange:t.handleOnChangeInputSecondLevel,onSelectChange:t.handleOnChangeSelectSecondLevel}),r().createElement(c.Field,{label:"SSL",description:"SSL required or not"},r().createElement("div",{style:{display:"flex",alignItems:"center"}},r().createElement(c.InlineLabel,{transparent:!0,width:7,style:{marginRight:"10px"}},e.ssl?"Enabled":"Disabled"),r().createElement(c.Switch,{value:e.ssl,onClick:e=>t.handleOnChangeSwitch(e,N)}))),e.ssl&&r().createElement(we,{sslData:e.sslData,protocol:n,onBlur:t.handleOnBlurCodeEditorSecondLevel})),r().createElement("div",{style:{marginBottom:"40px"}},r().createElement("h4",null,"Message mapping"),r().createElement("hr",{style:{marginBottom:"20px"}}),r().createElement("div",{style:{display:"flex",justifyContent:"center",marginBottom:"15px"}},r().createElement(c.Button,{variant:"secondary",onClick:t.handleAddMapper},"Add JavaScript mapping")),r().createElement(he,{payloadMapping:e.payloadMapping,sources:e.sources,targets:e.targets,onChange:t.handleOnChangeInputInList,onBlur:t.handleOnBlurCodeEditorPM,onRemove:t.handleOnClickRemove})),r().createElement("div",{style:{marginBottom:"40px"}},r().createElement("h4",null,"Sources"),r().createElement("hr",{style:{marginBottom:"20px"}}),r().createElement("div",{style:{display:"flex",justifyContent:"center",marginBottom:"15px"}},r().createElement(c.Button,{variant:"secondary",onClick:t.handleAddSource},"Add source")),r().createElement(be,{sources:e.sources,qosOptions:i,pmOptions:o,onInputChange:t.handleOnChangeInputInList,onSelectChange:t.handleOnChangeSelectInList,onBlurOthers:t.handleOnBlurCodeEditorOthers,onRemove:t.handleOnClickRemove})),r().createElement("div",{style:{marginBottom:"10px"}},r().createElement("h4",null,"Targets"),r().createElement("hr",{style:{marginBottom:"20px"}}),r().createElement("div",{style:{display:"flex",justifyContent:"center",marginBottom:"15px"}},r().createElement(c.Button,{variant:"secondary",onClick:t.handleAddTarget},"Add target")),r().createElement(ve,{targets:e.targets,protocol:n,qosOptions:i,pmOptions:o,onInputChange:t.handleOnChangeInputInList,onSelectChange:t.handleOnChangeSelectInList,onBlurOthers:t.handleOnBlurCodeEditorOthers,onRemove:t.handleOnClickRemove})))},Oe=({jsonOtherConnection:e,setJsonOtherConnection:t})=>r().createElement("div",{style:{width:"100%",marginBottom:"10px"}},r().createElement("h4",null," Connection definition "),r().createElement("hr",{style:{marginBottom:"20px"}}),r().createElement(c.CodeEditor,{value:JSON.stringify(e,null,"\t"),language:"json",height:600,width:"100%",onBlur:e=>{try{t(JSON.parse(e))}catch(e){console.error("Invalid JSON entered",e)}},showLineNumbers:!0,showMiniMap:!1,monacoOptions:{formatOnPaste:!0,formatOnType:!0}}));var Ce=n(213);const Se=n.n(Ce)().getLogger("ConnectionForm");Se.setLevel("trace");const ke=Se,Te=e=>(e||[]).join(", "),Pe=e=>void 0===e||e<0||e>2?$:{label:e.toString(),value:e},Ne=(e,t)=>{const n={};for(const a in e)t.includes(a)||(n[a]=e[a]);return Object.keys(n).length>0?JSON.stringify(n,null,2):""};function je(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function Ie(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){je(e,t,n[t])}))}return e}function De(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}function Ae({path:e,existingConnectionId:t}){const n=(0,c.useStyles2)(Re),l=(0,i.getAppEvents)(),d=(0,o.useHistory)(),{url:p}=(0,o.useRouteMatch)(),[u,m]=(0,a.useState)(!1),[f,y]=(0,a.useState)(w[0]),[v,E]=(0,a.useState)(h),[$,N]=(0,a.useState)(!1),[j,R]=(0,a.useState)(!!t),{currentConnection:L,setCurrentConnection:z,handlers:B}=((e=P)=>{const[t,n]=(0,a.useState)(e),r=(0,a.useCallback)((e=>{const{name:t,value:a}=e.currentTarget;n((e=>H(_({},e),{[t]:a})))}),[]),o=(0,a.useCallback)(((e,t)=>{const{name:a,value:r}=e.currentTarget;n((e=>H(_({},e),{[t]:H(_({},e[t]),{[a]:r})})))}),[]),i=(0,a.useCallback)(((e,t,a,r)=>{n((n=>{const o=[...n[t]];return o[r]=H(_({},o[r]),{[a]:e}),H(_({},n),{[t]:o})}))}),[]),l=(0,a.useCallback)(((e,t,a)=>{n((n=>H(_({},n),{[t]:H(_({},n[t]),{[a]:e})})))}),[]),s=(0,a.useCallback)(((e,t,a)=>{const{name:r,value:o}=e.currentTarget;n((e=>{const n=[...e[t]];return n[a]=H(_({},n[a]),{[r]:o}),H(_({},e),{[t]:n})}))}),[]),c=(0,a.useCallback)(((e,t)=>{n((n=>H(_({},n),{[e]:[...n[e],t]})))}),[]),d=(0,a.useCallback)(((e,t)=>{n((n=>{const a=[...n[e]];return a.splice(t,1),H(_({},n),{[e]:a})}))}),[]),p=(0,a.useCallback)(((e,t)=>{n((n=>{const a=[...n.payloadMapping];return a[t].code=e,H(_({},n),{payloadMapping:a})}))}),[]),u=(0,a.useCallback)(((e,t,a)=>{n((n=>{const r=[...n[a]];return r[t][M]=e,H(_({},n),{[a]:r})}))}),[]),m=(0,a.useCallback)(((e,t,a)=>{n((n=>H(_({},n),{[t]:H(_({},n[t]),{[a]:e})})))}),[]),g=(0,a.useCallback)(((e,t)=>{const a=e.target.checked;n((e=>H(_({},e),{[t]:a})))}),[]),f=(0,a.useCallback)((()=>c(I,C)),[c]),y=(0,a.useCallback)((()=>c(D,S)),[c]),h=(0,a.useCallback)((()=>c(A,k)),[c]);return{currentConnection:t,setCurrentConnection:n,handlers:{handleOnChangeInput:r,handleOnChangeInputSecondLevel:o,handleOnChangeSelectInList:i,handleOnChangeSelectSecondLevel:l,handleOnChangeInputInList:s,handleOnClickAdd:c,handleOnClickRemove:d,handleOnBlurCodeEditorPM:p,handleOnBlurCodeEditorOthers:u,handleOnBlurCodeEditorSecondLevel:m,handleOnChangeSwitch:g,handleAddMapper:f,handleAddSource:y,handleAddTarget:h}}})(P),F=()=>{const e=p.split("/connections")[0]+"/connections";d.push(e)};(0,a.useEffect)((()=>{g().then((e=>{e||(ke.warn("[Auth] User lacks permissions. Redirecting."),d.replace("/"))}))}),[]),(0,a.useEffect)((()=>{var e;t&&(ke.info(`[ConnectionForm] Edit mode enabled. Loading ID: ${t}`),N(!0),R(!0),(e=t,ae((function*(){return yield te(`${ee}/connections/${e}`,{method:"GET"})}))()).then((e=>{const n="kafka"===e.connectionType?b.KAFKA:"mqtt-5"===e.connectionType?b.MQTT5:b.OTHERS;if(n===b.OTHERS)z(De(Ie({},P),{id:t})),E(De(Ie({},e),{id:void 0}));else{const t=(e=>{var t,n;if(!e)return P;const a=e.mappingDefinitions?Object.keys(e.mappingDefinitions).map((t=>{var n,a;return{id:t,code:(null===(a=e.mappingDefinitions[t])||void 0===a||null===(n=a.options)||void 0===n?void 0:n.incomingScript)||C.code}})):[],r=e=>{if("Ditto"===e||!e)return O;const t=a.find((t=>t.id===e));return t?{label:t.id,value:t.id}:O},o=(e.sources||[]).map((e=>({addresses:Te(e.addresses),authorizationContext:Te(e.authorizationContext),qos:Pe(e.qos),payloadMapping:r(e.payloadMapping?e.payloadMapping[0]:void 0),others:Ne(e,["addresses","qos","payloadMapping"])}))),i=(e.targets||[]).map((e=>({address:e.address||"",topics:Te(e.topics),authorizationContext:Te(e.authorizationContext),qos:Pe(e.qos),payloadMapping:r(e.payloadMapping?e.payloadMapping[0]:void 0),others:Ne(e,["address","topics","qos","payloadMapping"])}))),l=e.specificConfig?{bootstrapServers:e.specificConfig.bootstrapServers||"",saslMechanism:(s=e.specificConfig.saslMechanism,x.find((e=>e.label===s))||x[0])}:T;var s;const c={ca:e.ca||"",cert:(null===(t=e.credentials)||void 0===t?void 0:t.cert)||"",key:(null===(n=e.credentials)||void 0===n?void 0:n.key)||""},d=(e=>{let t=e.replace("tcp://","").replace("ssl://",""),n="",a="",r=!1,o=t;if(t.includes("@")){const e=t.split("@");o=e.pop()||"";const i=e.join("@").split(":");n=i[0]||"",a=i.slice(1).join(":")||"",r=!0}return{host:o,username:n,password:a,hasAuth:r}})(e.uri||"");return{id:e.name||"",uri:d.host,username:d.username,password:d.password,hasAuth:d.hasAuth,ssl:(e.uri||"").startsWith("ssl://"),initStatus:"open"===(e.connectionStatus||"open"),payloadMapping:a,sources:o,targets:i,kafkaData:l,sslData:c}})(e);z(t)}y({label:n,value:n})})).catch((e=>{l.publish({type:s.AppEvents.alertError.name,payload:["Failed to load connection data: "+e.message]})})).finally((()=>N(!1))))}),[t]);if($)return r().createElement("div",{style:{display:"flex",justifyContent:"center",padding:50}},r().createElement(c.Spinner,{size:20}));const q=u?j?"Updating...":"Creating...":j?"Update Connection":"Create Connection",G=u?"spinner":void 0;return r().createElement("div",{className:n.centeredWrapper},r().createElement("div",{className:n.formPanel},r().createElement("div",{className:n.header},r().createElement("h2",null,j?`Edit Connection: ${L.id}`:"Create New Connection"),r().createElement(c.Button,{variant:"secondary",fill:"outline",icon:"arrow-left",onClick:F},"Back to list")),r().createElement("div",{className:n.radioGroupContainer},r().createElement(c.RadioButtonGroup,{options:w,value:f.value,onChange:e=>y({label:e,value:e}),disabled:j})),r().createElement(c.Form,{id:"finalForm",onSubmit:()=>{let e;if(ke.info("[ConnectionForm] Submitting connection form..."),m(!0),f.value===b.OTHERS)if(j){const n=De(Ie({},v),{id:t});e=oe(n)}else e=oe(v);else{const t=((e,t)=>{const n=e.ssl?"ssl://":"tcp://";let a=e.uri;e.hasAuth&&e.username&&(a=`${e.password?`${e.username}:${e.password}`:e.username}@${e.uri}`);const r=n+a;let o={name:e.id,connectionType:t===b.KAFKA?"kafka":"mqtt-5",connectionStatus:e.initStatus?"open":"closed",failoverEnabled:!0,uri:r,sources:[],targets:[]};if(t===b.KAFKA&&(o.specificConfig={bootstrapServers:e.kafkaData.bootstrapServers,saslMechanism:e.kafkaData.saslMechanism.label}),e.ssl&&(void 0!==e.sslData.ca&&""!==e.sslData.ca.trim()&&(o.validateCertificates=!0,o.ca=e.sslData.ca),e.sslData.cert&&e.sslData.key&&(o.credentials={type:"client-cert",cert:e.sslData.cert,key:e.sslData.key})),e.sources.forEach(((e,t)=>{var n;o.sources[t]={addresses:fe(e.addresses),authorizationContext:fe(e.authorizationContext),qos:e.qos.value,payloadMapping:[null===(n=e.payloadMapping)||void 0===n?void 0:n.value]};try{o.sources[t]=me({},o.sources[t],JSON.parse(e.others))}catch(e){}})),e.targets.forEach(((e,n)=>{var a;o.targets[n]={address:e.address,topics:fe(e.topics),authorizationContext:fe(e.authorizationContext),payloadMapping:[null===(a=e.payloadMapping)||void 0===a?void 0:a.value]};try{o.targets[n]=me({},o.targets[n],JSON.parse(e.others))}catch(e){}t===b.MQTT5&&(o.targets[n].qos=e.qos.value)})),e.payloadMapping.length>0){let t={};e.payloadMapping.forEach((e=>{t=ge(me({},t),{[e.id]:{mappingEngine:"JavaScript",options:{incomingScript:e.code.replaceAll("\t","").replaceAll("\r\n"," ").replaceAll('"',"'")}}})})),o.mappingDefinitions=t}return o})(L,f.value);n=L.id,a=t,e=ae((function*(){return yield te(`${ee}/connections/${n}`,{method:"PUT",data:a})}))()}var n,a;e.then((()=>{ke.info(`[ConnectionForm] Connection ${j?"updated":"created"} successfully.`),l.publish({type:s.AppEvents.alertSuccess.name,payload:["Connection "+(j?"updated":"created")]}),F()})).catch((e=>{ke.error("[ConnectionForm] Request failed:",e);let t="";try{const n=JSON.parse(e.message);t=n.message+". "+n.description}catch(e){}l.publish({type:s.AppEvents.alertError.name,payload:[`Connection has not been ${j?"updated":"created"}. `+t]})})).finally((()=>{m(!1)}))},className:n.formContainer},(({register:e,errors:t,control:n})=>r().createElement(r().Fragment,null,(()=>{switch(f.value){case b.KAFKA:case b.MQTT5:return r().createElement($e,{connectionData:L,handlers:B,protocol:f.value,isEditMode:j});default:return r().createElement(Oe,{jsonOtherConnection:v,setJsonOtherConnection:E})}})()))),r().createElement("div",{className:n.buttonGroup},r().createElement(c.Button,{variant:"primary",type:"submit",form:"finalForm",disabled:u,icon:G},q))))}const Re=e=>({centeredWrapper:l.css`
        display: flex;
        justify-content: center;
        width: 100%;
        padding-bottom: ${e.spacing(4)};
    `,formPanel:l.css`
        background-color: ${e.colors.background.primary};
        border: 1px solid ${e.colors.border.weak};
        border-radius: ${e.shape.borderRadius()};
        padding: ${e.spacing(4)};
        box-shadow: ${e.shadows.z1};
        width: 100%;
        max-width: 900px;
        display: flex;
        flex-direction: column;
    `,header:l.css`
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: ${e.spacing(3)};
        border-bottom: 1px solid ${e.colors.border.weak};
        padding-bottom: ${e.spacing(2)};
        
        h2 {
            margin: 0;
            font-size: ${e.typography.h3.fontSize};
        }
    `,radioGroupContainer:l.css`
        display: flex;
        justify-content: center;
        width: 100%;
        margin-bottom: ${e.spacing(3)};
    `,formContainer:l.css`
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        width: 100%;
    `,buttonGroup:l.css`
        display: flex;
        justify-content: flex-end;
        gap: ${e.spacing(2)};
        margin-top: ${e.spacing(4)};
        padding-top: ${e.spacing(2)};
        border-top: 1px solid ${e.colors.border.weak};
    `}),Le=e=>({container:l.css`
            padding: ${e.spacing(2)};
            height: 100%;
            display: flex;
            flex-direction: column;
        `,mainLayout:l.css`
            display: flex;
            flex-direction: row;
            gap: ${e.spacing(3)};
            height: 100%;
            /* Responsive: Apilar en pantallas pequeñas */
            @media (max-width: 1000px) {
                flex-direction: column;
            }
        `,leftPanel:l.css`
            flex: 0 0 400px; /* Ancho base fijo, pero flexible si es necesario */
            min-width: 350px;
            display: flex;
            flex-direction: column;
            gap: ${e.spacing(2)};
            padding: ${e.spacing(2)};
            background: ${e.colors.background.secondary};
            border: 1px solid ${e.colors.border.weak};
            border-radius: ${e.shape.borderRadius()};
            height: fit-content;
            max-height: 100%;
            overflow-y: auto;

            @media (max-width: 1000px) {
                flex: 1;
                max-height: none;
                width: 100%;
            }
        `,rightPanel:l.css`
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: ${e.spacing(2)};
            padding: ${e.spacing(2)};
            background: ${e.colors.background.secondary};
            border: 1px solid ${e.colors.border.weak};
            border-radius: ${e.shape.borderRadius()};
            height: 100%;
            min-height: 700px;
            overflow-y: auto;
        `,panelHeader:l.css`
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid ${e.colors.border.weak};
            padding-bottom: ${e.spacing(1.5)};
            margin-bottom: ${e.spacing(1)};
        `,panelTitle:l.css`
            font-size: ${e.typography.h4.fontSize};
            font-weight: ${e.typography.fontWeightBold};
            margin: 0;
        `,toolbar:l.css`
            display: flex;
            flex-direction: column;
            gap: ${e.spacing(2)};
        `,editorContainer:l.css`
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        `,definitionTextArea:l.css`
            font-family: ${e.typography.fontFamilyMonospace} !important;
            font-size: 12px;
            min-height: 492px;
            resize: vertical;
        `,debugGrid:l.css`
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: ${e.spacing(2)};
        `,debugItem:l.css`
             background: ${e.colors.background.primary};
             padding: ${e.spacing(2)};
             border-radius: ${e.shape.borderRadius()};
             border: 1px solid ${e.colors.border.weak};
        `,noPermission:l.css`
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: ${e.colors.text.secondary};
        `}),Me=({selected:e,onDelete:t,onEdit:n,onToggleStatus:o,isLoading:i})=>{const[l,s]=(0,a.useState)(!1);if(!(null==e?void 0:e.value))return null;const{connectionStatus:d}=e.value,p="open"===(null==d?void 0:d.toLowerCase());let u=p?"lock":"unlock";i&&(u="spinner");let m=p?"Close":"Open";return i&&(m=p?"Closing...":"Opening..."),r().createElement("div",{style:{display:"flex",gap:"8px",flexWrap:"wrap"}},e.value.hasOwnProperty("connectionStatus")&&r().createElement(c.Button,{variant:"secondary",onClick:o,icon:u,disabled:i},m),r().createElement(c.Button,{variant:"secondary",icon:"pen",onClick:n,disabled:i},"Edit"),r().createElement(c.Button,{variant:"destructive",icon:"trash-alt",onClick:()=>s(!0),disabled:i},"Delete"),r().createElement(c.ConfirmModal,{isOpen:l,title:"Delete connection",body:"Are you sure you want to delete this connection? This action cannot be undone.",confirmText:"Confirm Delete",icon:"exclamation-triangle",onConfirm:()=>{t(),s(!1)},onDismiss:()=>s(!1)}))},ze=({title:e,data:t,isLoading:n,onLoad:a,onRefresh:o,showRefresh:i=!1})=>{const l=n?"spinner":"history",s=n?"spinner":"sync",d=(null==t?void 0:t.timestamp)?new Date(t.timestamp).toLocaleString():null,p=(null==t?void 0:t.text)?JSON.stringify(t.text,void 0,2):"";return r().createElement("div",{style:{display:"flex",flexDirection:"column",height:"100%"}},r().createElement("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"8px"}},r().createElement("h6",{style:{margin:0,fontWeight:500}},e),d&&r().createElement("span",{style:{fontSize:"10px",color:"#888"}},d)),r().createElement("div",{style:{display:"flex",gap:"8px",marginBottom:"8px"}},r().createElement(c.Button,{style:{flexGrow:1},variant:"secondary",size:"sm",disabled:n,icon:l,onClick:a},"Load"),i&&r().createElement(c.Button,{variant:"secondary",size:"sm",disabled:n,icon:s,onClick:o},"Reset")),r().createElement(c.TextArea,{rows:15,value:p,readOnly:!0,style:{flexGrow:1,fontFamily:"monospace",fontSize:"11px",minHeight:"550px"}}))};function Be(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function Fe(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){Be(o,a,r,i,l,"next",e)}function l(e){Be(o,a,r,i,l,"throw",e)}i(void 0)}))}}function qe(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function Ge(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){qe(e,t,n[t])}))}return e}function Ue(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const _e=({path:e})=>{const t=(0,c.useStyles2)(Le),[n,l]=(0,a.useState)(u.VIEWER),[d,p]=(0,a.useState)([]),[g,f]=(0,a.useState)(),[h,b]=(0,a.useState)({logs:!1,metrics:!1,status:!1}),[v,E]=(0,a.useState)(),[w,x]=(0,a.useState)(!1),$=(0,i.getAppEvents)(),O=(0,o.useHistory)(),{url:C}=(0,o.useRouteMatch)();(0,a.useEffect)((()=>{S(),m().then((e=>l(e)))}),[]),(0,a.useEffect)((()=>{if(g&&g.value&&g.value.hasOwnProperty("id")){const e=d.find((e=>e.label===g.value.id));f(e)}}),[d]),(0,a.useEffect)((()=>{E({logs:void 0,metrics:void 0,status:void 0}),b({logs:!1,metrics:!1,status:!1})}),[null==g?void 0:g.value]);const S=()=>{ae((function*(){return yield te(`${ee}/connections`,{method:"GET"})}))().then((e=>{p(e.map((e=>({label:e.name,value:e}))))})).catch((()=>{$.publish({type:s.AppEvents.alertError.name,payload:["Error fetching connections"]})}))},k=(e,t)=>Fe((function*(){if(!g)return;const{id:n}=g.value,a=Date.now();b((t=>Ue(Ge({},t),{[e]:!0})));try{const r=yield t(n);let o;if("string"==typeof r)try{o=JSON.parse(r)}catch(e){o=r}else o=r;E((t=>Ue(Ge({},t),{[e]:{timestamp:a,text:o}})))}catch(t){$.publish({type:s.AppEvents.alertError.name,payload:[`Error getting the ${e} of connection with id ${n}: ${t.message}`]})}finally{b((t=>Ue(Ge({},t),{[e]:!1})))}}))(),T=(e,t)=>{E((n=>Ue(Ge({},n),{logs:{timestamp:t,text:e}})))};if(!y(n,u.EDITOR))return r().createElement("div",{className:t.noPermission},r().createElement(c.Icon,{name:"lock",size:"xxl",style:{marginBottom:"10px"}}),r().createElement("h5",null,"You do not have sufficient permissions to access this content"));const P=(null==g?void 0:g.value)?JSON.stringify(g.value,void 0,2):"";return r().createElement("div",{className:t.container},r().createElement("div",{className:t.mainLayout},r().createElement("div",{className:t.leftPanel},r().createElement("div",{className:t.panelHeader},r().createElement("span",{className:t.panelTitle},"Connections"),r().createElement(c.LinkButton,{variant:"primary",onClick:()=>O.push(`${C}/new`),icon:"plus",size:"sm"},"New")),r().createElement("div",{className:t.toolbar},r().createElement(c.Select,{options:d,value:g,onChange:e=>f(e),prefix:r().createElement(c.Icon,{name:"search"}),placeholder:"Select connection..."}),g&&r().createElement(Me,{selected:g,onEdit:()=>{void 0!==g&&g.value&&g.value.id&&O.push(`${C}/${g.value.id}/edit`)},onDelete:()=>{var e;void 0!==g&&g.value&&((e=g.value.id,ae((function*(){return yield te(`${ee}/connections/${e}`,{method:"DELETE"})}))()).then((()=>{$.publish({type:s.AppEvents.alertSuccess.name,payload:["Connection deleted successfully"]})})).catch((e=>{let t="";try{const n=JSON.parse(e.message);t=n.message+". "+n.description}catch(e){}$.publish({type:s.AppEvents.alertError.name,payload:["Connection has not been deleted. "+t]})})),f({value:void 0,label:void 0}),S())},onToggleStatus:()=>Fe((function*(){var e;if(!(null==g||null===(e=g.value)||void 0===e?void 0:e.id)||!g.value.hasOwnProperty("connectionStatus"))return;const{id:t,connectionStatus:n}=g.value,a="closed"===n.toLowerCase(),r=a?ce:re,o=a?"opened":"closed",i=a?"opening":"closing";x(!0);try{yield r(t),$.publish({type:s.AppEvents.alertSuccess.name,payload:[`Connection ${t} ${o} correctly!`]}),S()}catch(e){$.publish({type:s.AppEvents.alertError.name,payload:[`Error ${i} connection ${t}: ${e.message}`]})}finally{x(!1)}}))(),isLoading:w})),r().createElement("div",{className:t.editorContainer},r().createElement("div",{className:t.panelHeader,style:{marginTop:"16px",fontSize:"14px"}},r().createElement("span",null,"Definition")),r().createElement(c.TextArea,{className:t.definitionTextArea,value:P,readOnly:!0,placeholder:"// Select a connection to view its definition"}))),r().createElement("div",{className:t.rightPanel},r().createElement("div",{className:t.panelHeader},r().createElement("span",{className:t.panelTitle},"Debug Information")),g?r().createElement("div",{className:t.debugGrid},r().createElement("div",{className:t.debugItem},r().createElement(ze,{title:"Logs",data:null==v?void 0:v.logs,isLoading:h.logs,onLoad:()=>Fe((function*(){if(!g)return;const{id:e}=g.value,t=Date.now();b((e=>Ue(Ge({},e),{logs:!0})));try{const n=yield ie(e);let a;if("string"==typeof n)try{a=JSON.parse(n)}catch(e){return void T(n,t)}else a=n;if(a&&a.hasOwnProperty("enabledSince")&&null===a.enabledSince){$.publish({type:s.AppEvents.alertInfo.name,payload:["Logs not enabled. Attempting to enable automatically..."]}),yield(e=>ae((function*(){return yield te(`${ee}/connections/${e}/command`,{method:"POST",headers:{"Content-Type":"text/plain"},data:"connectivity.commands:enableConnectionLogs"})}))())(e),$.publish({type:s.AppEvents.alertSuccess.name,payload:["Logs enabled for 24h. Fetching logs again..."]});const t=yield ie(e);let n;if("string"==typeof t)try{n=JSON.parse(t)}catch(e){n=t}else n=t;T(n,Date.now())}else T(a,t)}catch(e){$.publish({type:s.AppEvents.alertError.name,payload:[`Error in log retrieval process: ${e.message}`]})}finally{b((e=>Ue(Ge({},e),{logs:!1})))}}))(),onRefresh:()=>k("logs",de),showRefresh:!0})),r().createElement("div",{className:t.debugItem},r().createElement(ze,{title:"Metrics",data:null==v?void 0:v.metrics,isLoading:h.metrics,onLoad:()=>k("metrics",le),onRefresh:()=>k("metrics",pe),showRefresh:!0})),r().createElement("div",{className:t.debugItem},r().createElement(ze,{title:"Status",data:null==v?void 0:v.status,isLoading:h.status,onLoad:()=>k("status",se),showRefresh:!1}))):r().createElement("div",{style:{display:"flex",justifyContent:"center",alignItems:"center",height:"100%",color:"#888"}},r().createElement("p",null,"Select a connection to view debug info")))))};var He=function(e){return e.List="list",e.Create="create",e.Edit="edit",e}({});const We=({meta:e,pageMode:t="list"})=>{const n=(0,c.useStyles2)(Je),{id:a}=(0,o.useParams)(),l="connections";return r().createElement(i.PluginPage,{layout:s.PageLayoutType.Canvas},r().createElement("div",{className:n.container},"create"===t?r().createElement(Ae,{path:l}):"edit"===t?a?r().createElement(Ae,{path:l,existingConnectionId:a}):r().createElement(c.Alert,{title:"Error"},"Connection ID is required for editing."):r().createElement(_e,{path:l})))},Je=e=>({container:l.css`
    display: flex;
    flex-direction: column;
    gap: ${e.spacing(2)};
    width: 100%;
  `}),Ke={ditto_endpoint:"",ditto_username:"",ditto_password:"",ditto_username_devops:"",ditto_password_devops:"",ditto_extended_endpoint:"",hono_endpoint:"",hono_tenant:"",agent_endpoint:"",agent_context:""},Ve=r().createContext(Ke),Ye=e=>Object.keys(e).map((t=>({name:t,properties:e[t].properties}))),Qe=e=>{let t={};if(void 0!==e.jsonData){const n=e.jsonData;void 0!==n.dittoURL&&(t.ditto_endpoint=n.dittoURL),void 0!==n.dittoUsername&&(t.ditto_username=n.dittoUsername),void 0!==n.dittoDevopsUsername&&(t.ditto_username_devops=n.dittoDevopsUsername),void 0!==n.extendedURL&&(t.ditto_extended_endpoint=n.extendedURL),void 0!==n.agentsURL&&(t.agent_endpoint=n.agentsURL),void 0!==n.agentsContext&&(t.agent_context=n.agentsContext)}return t},Xe=1,Ze=0;var et=function(e){return e.JSON="application/json",e.FORM="multipart/form-data",e}({}),tt=function(e){return e.GET="GET",e.POST="POST",e.PUT="PUT",e.PATCH="PATCH",e.DELETE="DELETE",e}({}),nt=function(e){return e.ARRAY_TEXT="array(text)",e.ARRAY_NUMBER="array(number)",e.ARRAY_BOOLEAN="array(boolean)",e.TEXT="text",e.NUMBER="number",e.BOOLEAN="boolean",e.FILE="file",e}({});const at=[{label:"From scratch",value:Ze},{label:"From existing type",value:Xe}],rt="simulationOf",ot=[rt,"_simulations"],it=["name","description","image"],lt=["_isType","_parents","type","copyOf"],st=[rt,"_parents","copyOf"],ct=(e,t,n)=>void 0!==e&&e.hasOwnProperty(t)?e[t]:n,dt=e=>e.charAt(0).toUpperCase()+e.slice(1),pt=e=>Object.fromEntries(Object.entries(e).filter((([e,t])=>null!=t&&void 0!==t&&""!==t))),ut=e=>"true"===e.trim().toLowerCase(),mt=e=>Number(e);var gt=function(e){return e.CONFIRM="confirm",e.SUCCESS="success",e.ERROR="error",e.HIDE="hide",e.LOADING="loading",e.READY="ready",e}({});const ft=e=>Object.entries(e).map((([e,t])=>({label:t,value:t}))),yt=(e,t,n)=>(t.reduce(((e,a,r)=>(r===t.length-1?e[a]=n:e[a]||(e[a]={}),e[a])),e),e),ht=e=>({centeredWrapper:l.css`
    display: flex;
    justify-content: center;
    width: 100%;
    padding-bottom: ${e.spacing(4)};
  `,formPanel:l.css`
    background-color: ${e.colors.background.primary};
    border: 1px solid ${e.colors.border.weak};
    border-radius: ${e.shape.borderRadius()};
    padding: ${e.spacing(4)};
    box-shadow: ${e.shadows.z1};
    width: 100%;
    max-width: 900px;
    display: flex;
    flex-direction: column;
  `,header:l.css`
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: ${e.spacing(3)};
    border-bottom: 1px solid ${e.colors.border.weak};
    padding-bottom: ${e.spacing(2)};
    
    h2 {
      margin: 0;
      font-size: ${e.typography.h3.fontSize};
    }
  `,formContainer:l.css`
    display: flex;
    flex-direction: column;
    flex-grow: 1;
    gap: ${e.spacing(2)};
  `,methodUrlGrid:l.css`
    display: grid;
    grid-template-columns: 160px 1fr; /* 160px para Method, el resto para URL */
    gap: ${e.spacing(2)};
    align-items: start;

    @media (max-width: 600px) {
      grid-template-columns: 1fr; /* En móviles, uno debajo del otro */
    }
  `,subSection:l.css`
    padding: ${e.spacing(2)};
    background: ${e.colors.background.secondary};
    border-radius: ${e.shape.borderRadius()};
    margin-bottom: ${e.spacing(2)};
    border: 1px solid ${e.colors.border.weak};
  `,sectionDesc:l.css`
    color: ${e.colors.text.secondary};
    font-size: ${e.typography.bodySmall.fontSize};
    margin-bottom: ${e.spacing(2)};
    margin-top: -${e.spacing(1)};
  `,textArea:l.css`
    font-family: ${e.typography.fontFamilyMonospace};
    min-height: 400px;
    resize: vertical;
    margin-top: ${e.spacing(2)};
    font-size: 12px;
  `,buttonGroup:l.css`
    display: flex;
    justify-content: flex-end;
    gap: ${e.spacing(2)};
    margin-top: ${e.spacing(4)};
    padding-top: ${e.spacing(2)};
    border-top: 1px solid ${e.colors.border.weak};
  `,fieldSet:l.css`
    margin-bottom: 0px;
  `});function bt(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function vt(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){bt(o,a,r,i,l,"next",e)}function l(e){bt(o,a,r,i,l,"throw",e)}i(void 0)}))}}const Et=(e,t)=>vt((function*(){return yield te(`${X}/twins/${e}`,{method:"PUT",data:t})}))(),wt=e=>vt((function*(){return yield te(`${X}/twins/${e}`,{method:"GET"})}))(),xt=(e,t=50,n="",a)=>vt((function*(){let r=`size(${t})`;e&&(r+=`,cursor(${e})`);const o="_parents",i=["ne(attributes/_isType,true)",a?`eq(attributes/${o},"${a}")`:`or(not(exists(attributes/${o})),eq(attributes/${o},null))`];if(n){const e=n.replace(/"/g,'\\"'),t=e.toLowerCase(),a=e.toUpperCase(),r=e.charAt(0).toUpperCase()+e.slice(1).toLowerCase(),o=`or(like(thingId,"*${e}*"),like(attributes/name,"*${e}*"),like(attributes/name,"*${t}*"),like(attributes/name,"*${a}*"),like(attributes/name,"*${r}*"))`;i.push(o)}const l=`and(${i.join(",")})`,s=`${Z}/search/things?option=${r}&filter=${l}`,c=yield te(s,{method:"GET",headers:{"Cache-Control":"no-cache",Pragma:"no-cache","X-Cache-Skip":"true"}});return(null==c?void 0:c.items)?{items:c.items,cursor:c.cursor}:Array.isArray(c)?{items:c,cursor:void 0}:{items:[],cursor:void 0}}))(),$t=()=>vt((function*(){let e,t=[];const n=`${Z}/search/things?filter=ne(attributes/_isType,true)&fields=thingId&option=size(200)`;do{const a=e?`${n},cursor(${e})`:n,r=yield te(a,{method:"GET"}),o=e=>e.map((e=>e.thingId));(null==r?void 0:r.items)?(t=t.concat(o(r.items)),e=r.cursor):Array.isArray(r)?(t=t.concat(o(r)),e=void 0):e=void 0}while(e);return t}))(),Ot=(e,t)=>vt((function*(){return yield te(`${X}/twins/${e}`,{method:"PATCH",data:t})}))(),Ct=e=>vt((function*(){return yield te(`${X}/twins/${e}`,{method:"DELETE"})}))(),St=(e,t,n)=>vt((function*(){const a={method:"POST"};return n&&(a.data=n),yield te(`${X}/twins/${e}/duplicate/${t}`,a)}))();function kt(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function Tt(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const Pt=(e,t)=>{let n={};return Object.entries(e).forEach((([e,a])=>{let r=t.find((t=>t.name===e));void 0!==r&&(n=Tt(function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){kt(e,t,n[t])}))}return e}({},n),{[e]:Nt(a,r.type)}))})),n},Nt=(e,t)=>{switch(t){case nt.ARRAY_BOOLEAN:return jt(e).map((e=>ut(e)));case nt.ARRAY_NUMBER:return jt(e).map((e=>mt(e)));case nt.ARRAY_TEXT:return jt(e);case nt.BOOLEAN:return ut(e);case nt.NUMBER:return mt(e);default:return e}},jt=e=>e.split(",");function It(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function Dt(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){It(o,a,r,i,l,"next",e)}function l(e){It(o,a,r,i,l,"throw",e)}i(void 0)}))}}const At=(e,t)=>Dt((function*(){let n;if(e.contentType&&e.content)switch(e.contentType){case et.JSON:t=Pt(t,e.content),n=JSON.stringify(t);break;case et.FORM:n=new FormData;for(const[e,a]of Object.entries(t))n.append(e,a)}return yield((e,t,n=!1)=>K((function*(){const a=yield fetch(e,t);if(!(a.ok||n&&404===a.status)){const e=yield a.text();throw new Error(e||`Error: ${a.status}`)}try{if(n&&404===a.status)return;return yield a.clone().json()}catch(e){return yield a.text()}}))())(e.url,{method:e.method,body:n,mode:"cors"})}))();function Rt(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function Lt(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function Mt(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){Lt(e,t,n[t])}))}return e}function zt(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const Bt=(e,t,n)=>{const r=(0,o.useHistory)(),i=tt.GET,l=void 0!==n,[s,c]=(0,a.useState)({id:"",url:"",method:i,content:void 0}),[d,p]=(0,a.useState)(gt.HIDE);(0,a.useEffect)((()=>{n&&(p(gt.LOADING),((e,t)=>Dt((function*(){return yield te(`${Z}/things/${e}/attributes/_simulations/${t}`,{method:"GET"})}))())(e,n).then((e=>{c(e),p(gt.HIDE)})).catch((()=>p(gt.ERROR))))}),[e,n]);return{simulation:s,isEditMode:l,notificationState:d,setNotificationState:p,updateAttribute:(e,t)=>{c((n=>zt(Mt({},n),{[e]:t})))},handleAddContent:e=>{var t;const n={name:e.name,type:null===(t=e.typeSelect)||void 0===t?void 0:t.value,required:e.required,default:""===e.default?void 0:e.default};c((e=>{const t=e.content||[],a=t.some((e=>e.name===n.name))?t.map((e=>e.name===n.name?n:e)):[...t,n];return zt(Mt({},e),{content:a})}))},handleDeleteContent:e=>{c((t=>{var n;return zt(Mt({},t),{content:null===(n=t.content)||void 0===n?void 0:n.filter((t=>t.name!==e))})}))},handleSubmit:()=>{return(t=function*(){p(gt.LOADING);try{yield((e,t)=>Dt((function*(){return yield Ot(e,{attributes:{_simulations:{[t.id]:t}}})}))())(e,s),p(gt.SUCCESS)}catch(e){p(gt.ERROR)}},function(){var e=this,n=arguments;return new Promise((function(a,r){var o=t.apply(e,n);function i(e){Rt(o,a,r,i,l,"next",e)}function l(e){Rt(o,a,r,i,l,"throw",e)}i(void 0)}))})();var t},handleClear:()=>{c({id:"",url:"",method:i,content:void 0})},goBackToList:()=>{r.push(t)}}},Ft=({items:e,onDelete:t,onEdit:n,disabled:a})=>{const o=(0,c.useStyles2)(qt);return 0===e.length?r().createElement("div",{className:o.emptyState},"No content fields added yet."):r().createElement("div",{className:o.listWrapper},e.map((e=>r().createElement(c.Card,{key:e.name,className:o.card},r().createElement(c.Card.Heading,null,e.name),r().createElement(c.Card.Meta,null,e.type," ",e.required?"(Required)":""),r().createElement(c.Card.SecondaryActions,null,n&&r().createElement(c.IconButton,{name:"pen",tooltip:"Edit",onClick:()=>n(e),disabled:a}),r().createElement(c.IconButton,{name:"trash-alt",tooltip:"Delete",onClick:()=>t(e.name),disabled:a,variant:"destructive"}))))))},qt=e=>({listWrapper:l.css`
    display: flex;
    flex-direction: column;
    gap: ${e.spacing(1)};
  `,card:l.css`
    margin-bottom: 0 !important;
    padding: ${e.spacing(1)} !important;
  `,emptyState:l.css`
    color: ${e.colors.text.secondary};
    font-style: italic;
    padding: ${e.spacing(1)};
  `});var Gt=n(215);function Ut(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function _t(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){Ut(e,t,n[t])}))}return e}function Ht(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const Wt=({onAdd:e,disabled:t})=>{const{register:n,control:a,handleSubmit:o,reset:i}=(0,Gt.mN)(),l=ft(nt);return r().createElement("form",{onSubmit:o((t=>{e(t),i({name:"",default:"",required:!1,typeSelect:void 0})}))},r().createElement("div",{style:{display:"flex",gap:"16px",alignItems:"flex-start",flexWrap:"wrap"}},r().createElement(c.Field,{label:"Name",required:!0,style:{flex:1,minWidth:"150px"}},r().createElement(c.Input,Ht(_t({},n("name",{required:!0})),{disabled:t,placeholder:"param_name"}))),r().createElement(c.Field,{label:"Type",required:!0,style:{flex:1,minWidth:"150px"}},r().createElement(Gt.xI,{name:"typeSelect",control:a,rules:{required:!0},render:({field:{onChange:e,value:n}})=>r().createElement(c.Select,{options:l,value:n,onChange:e,disabled:t,placeholder:"Select type"})})),r().createElement(c.Field,{label:"Default Value",style:{flex:1,minWidth:"150px"}},r().createElement(c.Input,Ht(_t({},n("default")),{disabled:t,placeholder:"Optional"}))),r().createElement(c.Field,{label:"Req.",description:"Required?"},r().createElement(c.Switch,Ht(_t({},n("required")),{disabled:t}))),r().createElement("div",{style:{paddingTop:"22px"}},r().createElement(c.Button,{type:"submit",variant:"secondary",disabled:t,icon:"plus"},"Add"))))},Jt=({path:e,meta:t,id:n,simulationId:i})=>{const l=(0,c.useStyles2)(ht),{url:s}=(0,o.useRouteMatch)(),d=s.split("/simulations")[0]+"/simulations",p=Bt(n,d,i),{simulation:u,isEditMode:m,notificationState:g,updateAttribute:f,goBackToList:y}=p,[h,b]=(0,a.useState)(!1),v=ft(tt),E=ft(et),w=g===gt.LOADING,x=!!u.content||void 0!==u.content&&null!==u.content,$=m?`Edit Simulation: ${i}`:"Create New Simulation",O=m?"Save Changes":"Create Simulation";return r().createElement("div",{className:l.centeredWrapper},g===gt.SUCCESS?m?r().createElement(c.Modal,{isOpen:!0,title:"Successful edition!",icon:"check",onDismiss:()=>p.setNotificationState(gt.HIDE)},"You can re-edit the simulation or leave the page."):r().createElement(c.ConfirmModal,{isOpen:!0,title:"Successful creation!",body:"What would you like to do next?",confirmText:"Clear fields (New)",dismissText:"Keep fields",icon:"check",onConfirm:()=>{p.handleClear(),p.setNotificationState(gt.HIDE)},onDismiss:()=>p.setNotificationState(gt.HIDE)}):g===gt.ERROR?r().createElement(c.Modal,{isOpen:!0,title:"Error",icon:"exclamation-triangle",onDismiss:()=>p.setNotificationState(gt.HIDE)},"The simulation could not be saved. Please check the data."):null,r().createElement("div",{className:l.formPanel},r().createElement("div",{className:l.header},r().createElement("div",null,r().createElement("h2",null,$),r().createElement("div",{style:{opacity:.7,fontSize:"0.9em"}},"For Twin ID: ",n)),r().createElement(c.Button,{variant:"secondary",fill:"outline",icon:"arrow-left",onClick:y},"Back to list")),r().createElement("div",{className:l.formContainer},r().createElement(c.FieldSet,{label:"General Details"},r().createElement(c.Field,{label:"ID",required:!m,description:"Unique identifier for this simulation."},r().createElement(c.Input,{value:u.id,onChange:e=>f("id",e.currentTarget.value),required:!0,disabled:m||w,placeholder:"sim-001"})),r().createElement(c.Field,{label:"Description",description:"Short description of what this simulation does."},r().createElement(c.Input,{value:u.description||"",onChange:e=>f("description",e.currentTarget.value),disabled:w,placeholder:"e.g. Simulate temperature rise"}))),r().createElement(c.FieldSet,{label:"Request Configuration",className:l.fieldSet},r().createElement("div",{className:l.methodUrlGrid},r().createElement(c.Field,{label:"Method",required:!0},r().createElement(c.Select,{options:v,value:u.method,onChange:e=>f("method",e.value),disabled:w})),r().createElement(c.Field,{label:"URL",required:!0},r().createElement(c.Input,{type:"url",value:u.url,onChange:e=>f("url",e.currentTarget.value),disabled:w,placeholder:"http://...",prefix:r().createElement(c.Icon,{name:"globe"})})))),r().createElement("div",null,r().createElement(c.Field,{label:"Enable Body Content?",description:"Configure fields to be sent in the body of the request."},r().createElement(c.Switch,{value:x,onChange:e=>{const t=e.currentTarget.checked;f("content",t?[]:void 0)},disabled:w})),x&&r().createElement("div",{className:l.subSection},r().createElement(c.Field,{label:"Content-Type",required:!0},r().createElement(c.Select,{options:E,value:u.contentType,onChange:e=>f("contentType",e.value),disabled:w})),r().createElement("hr",{style:{opacity:.1,margin:"16px 0"}}),r().createElement(Wt,{onAdd:p.handleAddContent,disabled:w}),r().createElement("div",{style:{marginTop:"16px"}},r().createElement(Ft,{items:u.content||[],onDelete:p.handleDeleteContent,disabled:w})))),r().createElement("div",{className:"mt-4"},r().createElement(c.Button,{variant:"secondary",size:"sm",fill:"text",icon:h?"angle-up":"angle-down",onClick:()=>b(!h)},h?"Hide JSON Preview":"Show JSON Preview"),h&&r().createElement(c.TextArea,{className:l.textArea,value:JSON.stringify(u,null,4),readOnly:!0}))),r().createElement("div",{className:l.buttonGroup},r().createElement(c.Button,{variant:"primary",onClick:p.handleSubmit,disabled:w,icon:w?"spinner":void 0},O))))};function Kt(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function Vt(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){Kt(o,a,r,i,l,"next",e)}function l(e){Kt(o,a,r,i,l,"throw",e)}i(void 0)}))}}const Yt=(e,t,n)=>Vt((function*(){const a={method:"PUT"};return n&&(a.data=n),yield te(`${X}/twins/${e}/children/${t}`,a)}))(),Qt=e=>Vt((function*(){return yield te(`${X}/twins/${e}/children`,{method:"DELETE"})}))(),Xt=({thingId:e,isType:t,funcDelete:n,funcDeleteChildren:i,enableCopy:l})=>{const s=(0,o.useHistory)(),{url:d}=(0,o.useRouteMatch)(),p=t?"types":"twins",g=d.split(`/${p}`)[0]+`/${p}`,y=t?"type":"twin",h=`Delete ${y}`,b=`Are you sure you want to remove the ${y} with id `,v=`The ${y} has been deleted correctly.`,E=`The ${y} has not been deleted correctly.`,[w,x]=(0,a.useState)(u.VIEWER),[$,O]=(0,a.useState)(),[C,S]=(0,a.useState)(gt.HIDE);(0,a.useEffect)((()=>{m().then((e=>x(e)))}),[]);const k=e=>{O(void 0),S(gt.HIDE),e&&s.push(g)},T=(e,t)=>{O(void 0),S(gt.LOADING);try{e(t).then((()=>{S(gt.SUCCESS)})).catch((()=>{S(gt.ERROR)}))}catch(e){S(gt.ERROR)}};return f(w)?r().createElement(a.Fragment,null,(()=>{if(void 0!==$){const e=$;return t||void 0===i?r().createElement(c.ConfirmModal,{isOpen:!0,title:h,body:b+`${e}?`,confirmText:"Delete",onConfirm:()=>T(n,e),onDismiss:()=>k(!1)}):r().createElement(c.ConfirmModal,{isOpen:!0,title:h,body:b+`${e}?`,description:"Choose if you want to remove the twin alone, unlinking its children, or remove the twin and all its children.",confirmationText:e,confirmText:"With children",alternativeText:"Without children",dismissText:"Cancel",onAlternative:()=>T(n,e),onDismiss:()=>k(!1),onConfirm:()=>T(i,e)})}switch(C){case gt.SUCCESS:return r().createElement(c.Modal,{title:v,icon:"check",isOpen:!0,onDismiss:()=>k(!0)});case gt.ERROR:return r().createElement(c.Modal,{title:E,icon:"exclamation-triangle",isOpen:!0,onDismiss:()=>k(!1)},"Refresh the page or check for errors.");case gt.LOADING:return r().createElement("div",{style:{display:"flex",justifyItems:"center",justifyContent:"center",alignContent:"center"}},r().createElement(c.Spinner,{size:30}));default:return null}})(),r().createElement("div",{style:{display:"flex",gap:"10px"}},r().createElement(c.Button,{icon:"copy",tooltip:"Copy",variant:"secondary",onClick:()=>{s.push(`${g}/${e}/copy`)},hidden:t},"Copy"),r().createElement(c.Button,{icon:"pen",tooltip:"Edit",variant:"secondary",onClick:()=>{s.push(`${g}/${e}/edit`)}},"Edit"),r().createElement(c.Button,{icon:"trash-alt",tooltip:"Delete",variant:"destructive",onClick:t=>{t.preventDefault(),O(e)}},"Delete"))):null},Zt=({thing:e,isType:t,sections:n,selected:a,setSelected:o,funcDelete:i,funcDeleteChildren:l,enableCopy:s=!1})=>{var d;const p=(0,c.useStyles2)(en),u=(0,c.useTheme2)(),m=null===(d=e.attributes)||void 0===d?void 0:d.image,g=ct(e.attributes,"name",e.thingId);return r().createElement("div",{className:p.container},r().createElement("div",{className:p.identityGroup},r().createElement("div",{className:p.imageContainer},m?r().createElement("img",{src:e.attributes.image,alt:g,className:p.image}):r().createElement("div",{className:p.placeholder},r().createElement(c.Icon,{name:"cube",size:"xxl",style:{color:u.colors.text.secondary}}))),r().createElement("div",{className:p.textContainer},r().createElement("h2",{className:p.title},g),r().createElement("div",{className:p.subtitle},r().createElement("span",{className:p.idLabel},"ID:")," ",e.thingId))),r().createElement("div",{className:p.navigationGroup},n.map((e=>r().createElement(c.FilterPill,{key:e,label:dt(e),selected:e===a,onClick:()=>o(e)})))),r().createElement("div",{className:p.actionsGroup},r().createElement(Xt,{thingId:e.thingId,isType:t,enableCopy:s,funcDelete:i,funcDeleteChildren:l})))},en=e=>({container:l.css`
        display: flex;
        flex-wrap: wrap; // Permite que baje de línea en pantallas pequeñas
        align-items: center;
        justify-content: space-between;
        padding: ${e.spacing(2)};
        background: ${e.colors.background.secondary};
        border-bottom: 1px solid ${e.colors.border.weak};
        gap: ${e.spacing(2)};
        margin-bottom: ${e.spacing(2)};
        margin-top: -${e.spacing(2)};
        margin-left: -${e.spacing(2)};
        margin-right: -${e.spacing(2)};
    `,identityGroup:l.css`
        display: flex;
        align-items: center;
        gap: ${e.spacing(2)};
        min-width: 250px;
    `,imageContainer:l.css`
        width: 64px;
        height: 64px;
        flex-shrink: 0;
    `,image:l.css`
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: ${e.shape.radius.default};
        border: 1px solid ${e.colors.border.weak};
        box-shadow: ${e.shadows.z1};
    `,placeholder:l.css`
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: ${e.colors.background.primary};
        border-radius: ${e.shape.radius.default};
        border: 1px dashed ${e.colors.border.medium};
    `,textContainer:l.css`
        display: flex;
        flex-direction: column;
        justify-content: center;
    `,title:l.css`
        margin: 0;
        font-size: ${e.typography.h3.fontSize};
        font-weight: ${e.typography.fontWeightMedium};
        line-height: 1.2;
    `,subtitle:l.css`
        margin: 0;
        font-size: ${e.typography.bodySmall.fontSize};
        color: ${e.colors.text.secondary};
        font-family: ${e.typography.fontFamilyMonospace};
        display: flex;
        align-items: center;
        gap: ${e.spacing(.5)};
    `,idLabel:l.css`
        font-weight: ${e.typography.fontWeightBold};
        text-transform: uppercase;
        font-size: 10px;
        margin-top: 2px;
        background: ${e.colors.background.primary};
        padding: 0 4px;
        border-radius: 3px;
    `,navigationGroup:l.css`
        display: flex;
        gap: ${e.spacing(1)};
        flex-wrap: wrap;
        justify-content: center;
        flex: 1; // Ocupa el espacio central disponible
    `,actionsGroup:l.css`
        display: flex;
        justify-content: flex-end;
    `}),tn=e=>({container:l.css`
        display: flex;
        flex-direction: column;
        height: 100%;
        gap: ${e.spacing(2)};
    `,toolbar:l.css`
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: ${e.spacing(2)};
        padding-bottom: ${e.spacing(2)};
        border-bottom: 1px solid ${e.colors.border.weak};
        flex-shrink: 0;
    `,searchBox:l.css`
        max-width: 400px;
        flex-grow: 1;
    `,splitLayout:l.css`
        display: flex;
        flex-grow: 1;
        gap: ${e.spacing(2)};
        overflow: hidden;
    `,leftColumn:l.css`
        flex: 1; /* 50% del espacio */
        overflow-y: auto;
        padding-right: ${e.spacing(1)};
        display: flex;
        flex-direction: column;
        gap: ${e.spacing(1)};
        
        &::-webkit-scrollbar { width: 6px; }
        &::-webkit-scrollbar-thumb { background: ${e.colors.action.disabledBackground}; border-radius: 3px; }
    `,rightColumn:l.css`
        flex: 1; /* 50% del espacio */
        padding: ${e.spacing(3)};
        background-color: ${e.colors.background.secondary};
        border-radius: ${e.shape.borderRadius()};
        border: 1px solid ${e.colors.border.weak};
        /* Si no hay nada seleccionado, centramos el mensaje */
        display: flex; 
        flex-direction: column;
    `,cardRow:l.css`
        display: flex;
        justify-content: space-between;
        padding: ${e.spacing(2)}; /* Un poco más de aire */
        border: 1px solid ${e.colors.border.weak};
        background: ${e.colors.background.elevated};
        cursor: pointer;
        border-radius: ${e.shape.borderRadius()};
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        &:hover {
            border-color: ${e.colors.primary.border};
            background-color: ${e.colors.background.primary};
            transform: translateY(-2px);
            box-shadow: ${e.shadows.z1};
        }
    `,cardRowSelected:l.css`
        border-color: ${e.colors.primary.main};
        background: ${e.colors.action.selected};
        &:hover { background: ${e.colors.action.selected}; }
    `,cardMainInfo:l.css`
        flex: 1;
        min-width: 0; 
        margin-right: ${e.spacing(2)};
    `,cardTitle:l.css`
        font-weight: 500;
        font-size: ${e.typography.h5.fontSize};
        margin-bottom: ${e.spacing(.5)};
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        color: ${e.colors.text.primary};
    `,cardDescription:l.css`
        color: ${e.colors.text.secondary};
        font-size: ${e.typography.bodySmall.fontSize};
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    `,cardMeta:l.css`
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        justify-content: center;
        gap: ${e.spacing(.5)};
        flex-shrink: 0;
        font-size: ${e.typography.bodySmall.fontSize};
    `,metaRow:l.css`
        display: flex;
        align-items: center;
        gap: ${e.spacing(1)};
        color: ${e.colors.text.secondary};
    `,urlText:l.css`
        max-width: 150px; /* Ajustado para el 50% */
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-family: ${e.typography.fontFamilyMonospace};
        font-size: 11px;
    `,panelHeader:l.css`
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: ${e.spacing(3)};
        border-bottom: 1px solid ${e.colors.border.weak};
        padding-bottom: ${e.spacing(2)};
    `,rowInputs:l.css`
        display: flex;
        gap: ${e.spacing(2)};
        width: 100%;
        margin-top: ${e.spacing(2)};
        > div { flex: 1; }
    `,centerMessage:l.css`
        margin: auto; /* Centrado perfecto en el flex container */
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: ${e.colors.text.secondary};
        text-align: center;
        opacity: 0.7;
        gap: ${e.spacing(2)};
    `,placeholder:l.css`
      background-color: ${e.colors.background.primary};
      color: ${e.colors.text.secondary};
      opacity: 1;
      padding: ${e.spacing(3)};
      border-radius: ${e.shape.borderRadius()};
      border: 1px solid ${e.colors.border.weak};
    `,centerContent:l.css`
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: ${e.spacing(2)};
      padding: ${e.spacing(4)};
      text-align: center;
    `,grid:l.css`
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: ${e.spacing(3)};
      @media (max-width: 768px) {
        grid-template-columns: 1fr;
      }
    `,column:l.css`
      display: flex;
      flex-direction: column;
      gap: ${e.spacing(2)};
    `});function nn(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function an(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){nn(o,a,r,i,l,"next",e)}function l(e){nn(o,a,r,i,l,"throw",e)}i(void 0)}))}}function rn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function on(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){rn(e,t,n[t])}))}return e}function ln(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const sn=({simulation:e,twinId:t,onSuccess:n,isEditor:l})=>{const d=(0,c.useStyles2)(tn),p=(0,i.getAppEvents)(),u=(0,o.useHistory)(),{url:m}=(0,o.useRouteMatch)(),[g,f]=(0,a.useState)(gt.HIDE),[y,h]=(0,a.useState)(!1),[b,v]=(0,a.useState)(""),[E,w]=(0,a.useState)(""),[x,$]=(0,a.useState)({});return r().createElement(a.Fragment,null,r().createElement("div",{className:d.panelHeader},r().createElement("div",null,r().createElement("h3",{style:{margin:0}},e.id),r().createElement("div",{style:{opacity:.7,fontSize:"12px"}},e.method," - ",e.url)),l&&r().createElement("div",{style:{display:"flex",gap:"8px"}},r().createElement(c.Button,{variant:"secondary",size:"md",icon:"pen",onClick:()=>u.push(`${m}/${e.id}/edit`)},"Edit"),r().createElement(c.Button,{"aria-label":"",variant:"destructive",size:"md",icon:"trash-alt",onClick:()=>an((function*(){if(confirm(`Are you sure you want to delete simulation "${e.id}"?`))try{yield((e,t)=>Dt((function*(){return yield Ot(e,{attributes:{_simulations:{[t]:null}}})}))())(t,e.id),n(),p.publish({type:s.AppEvents.alertSuccess.name,payload:["Simulation deleted successfully"]})}catch(e){p.publish({type:s.AppEvents.alertError.name,payload:["Error deleting simulation"]})}}))()},"Delete"))),r().createElement(c.Form,{onSubmit:n=>an((function*(){f(gt.LOADING);let a=on({},n,x);if(y){if(!b||!E)return p.publish({type:s.AppEvents.alertWarning.name,payload:["Namespace and ID are required to duplicate the twin"]}),void f(gt.HIDE);const n=`${b}:${E}`,r={attributes:{simulationOf:t}};try{yield St(t,n,r),p.publish({type:s.AppEvents.alertSuccess.name,payload:["Twin duplicated successfully"]}),delete a.thingId,a=pt(a),yield At(e,a),p.publish({type:s.AppEvents.alertSuccess.name,payload:["Simulation request submitted"]})}catch(e){console.error(e),p.publish({type:s.AppEvents.alertError.name,payload:["Error during duplication/simulation process"]})}}else{delete a.thingId,a=pt(a);try{yield At(e,a),p.publish({type:s.AppEvents.alertSuccess.name,payload:["Simulation request submitted"]})}catch(e){p.publish({type:s.AppEvents.alertError.name,payload:["Error calling simulation"]})}}f(gt.HIDE)}))(),maxWidth:"none"},(({register:t,control:n})=>{var o;return r().createElement(a.Fragment,null,r().createElement("div",{style:{marginBottom:"24px"}},r().createElement(c.Checkbox,{value:y,onChange:()=>h(!y),label:"Duplicate twin before executing",description:"Creates a copy with a new ID before simulating."}),y&&r().createElement("div",{className:d.rowInputs},r().createElement(c.Field,{label:"Namespace",required:!0},r().createElement(c.Input,{placeholder:"e.g. org.eclipse.ditto",value:b,onChange:e=>v(e.currentTarget.value)})),r().createElement(c.Field,{label:"ID",required:!0},r().createElement(c.Input,{placeholder:"e.g. my-twin-v2",value:E,onChange:e=>w(e.currentTarget.value)})))),((null===(o=e.content)||void 0===o?void 0:o.length)||0)>0&&r().createElement("h5",null,"Parameters"),r().createElement(c.FieldSet,null,((t,n)=>e.content?e.content.map(((e,a)=>e.type===nt.FILE?r().createElement(c.Field,{key:a,label:e.name,description:"Upload file",required:e.required},r().createElement(c.InputControl,{control:t,name:e.name,render:({field:t})=>r().createElement(c.FileUpload,ln(on({},t),{onFileUpload:({currentTarget:t})=>{t.files&&t.files[0]&&$((n=>ln(on({},n),{[e.name]:t.files[0]})))}}))})):r().createElement(c.Field,{key:a,label:e.name,description:e.type,required:e.required},r().createElement(c.Input,ln(on({},n(e.name,{required:e.required})),{type:e.type===nt.NUMBER?"number":"text",defaultValue:e.default}))))):null)(n,t)),r().createElement("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",marginTop:"20px"}},g===gt.LOADING&&r().createElement(c.Spinner,{size:20}),r().createElement(c.Button,{type:"submit",icon:"play",variant:"primary",disabled:g!==gt.HIDE},"Simulate")))})))},cn=({simulation:e,isSelected:t,onClick:n})=>{const a=(0,c.useStyles2)(tn);return r().createElement("div",{className:(0,l.cx)(a.cardRow,{[a.cardRowSelected]:t}),onClick:()=>n(e)},r().createElement("div",{className:a.cardMainInfo},r().createElement("div",{className:a.cardTitle,title:e.id},e.id),r().createElement("div",{className:a.cardDescription,title:e.description},e.description||"No description provided")),r().createElement("div",{className:a.cardMeta},r().createElement("div",{className:a.metaRow},e.contentType&&r().createElement(c.Tooltip,{content:`Content-Type: ${e.contentType}`},r().createElement(c.Icon,{name:"file-alt",style:{opacity:.7}})),r().createElement(c.Badge,{text:e.method,color:(e=>{switch(null==e?void 0:e.toUpperCase()){case"POST":return"green";case"GET":return"blue";case"PUT":return"orange";case"DELETE":return"red";default:return"darkgrey"}})(e.method)})),r().createElement("div",{className:a.metaRow},r().createElement(c.Tooltip,{content:e.url},r().createElement("div",{style:{display:"flex",alignItems:"center"}},r().createElement(c.Icon,{name:"link",style:{marginRight:4,opacity:.7},size:"sm"}),r().createElement("span",{className:a.urlText},e.url))))))},dn=({id:e,twinInfo:t})=>{var n;const i=(0,c.useStyles2)(tn),l=(0,o.useHistory)(),{url:s}=(0,o.useRouteMatch)(),[d,p]=(0,a.useState)(),[g,y]=(0,a.useState)([]),[h,b]=(0,a.useState)(u.VIEWER),[v,E]=(0,a.useState)("");(0,a.useEffect)((()=>{const e=ct(t.attributes,"_simulations",{}),n=Object.values(e).map((e=>(e.content&&e.content.sort(((e,t)=>e.required===t.required?0:e.required?-1:1)),e)));y(n),m().then(b)}),[t]);const w=(0,a.useMemo)((()=>{if(!v)return g;const e=v.toLowerCase();return g.filter((t=>t.id.toLowerCase().includes(e)||t.description&&t.description.toLowerCase().includes(e)||t.url.toLowerCase().includes(e)))}),[g,v]),x=e=>{(null==d?void 0:d.id)===e.id?p(void 0):p(e)},$=()=>l.push(`${s}/new`),O=()=>{var e;if(null===(e=t.attributes)||void 0===e?void 0:e.simulationOf){const e=s.split("/twins")[0];l.push(`${e}/twins/${t.attributes.simulationOf}`)}};var C;return(null===(n=t.attributes)||void 0===n?void 0:n.hasOwnProperty("simulationOf"))?r().createElement("div",{className:i.centerContent},r().createElement("h3",null,"Simulated Twin"),r().createElement("p",null,"This twin was created from a simulation. Access the original twin to perform new simulations."),(null===(C=t.attributes)||void 0===C?void 0:C.simulationOf)&&r().createElement(c.LinkButton,{icon:"external-link-alt",variant:"primary",onClick:O},"Go to ",t.attributes.simulationOf)):0===g.length?r().createElement("div",{className:i.centerContent},r().createElement("h3",null,"No simulations found"),r().createElement("p",null,"There are no simulations configured for this twin yet."),f(h)&&r().createElement(c.LinkButton,{icon:"plus",variant:"primary",onClick:$},"New Simulation")):r().createElement("div",{className:i.container},r().createElement("div",{className:i.toolbar},r().createElement("div",{className:i.searchBox},r().createElement(c.Input,{prefix:r().createElement(c.Icon,{name:"search"}),placeholder:"Search...",value:v,onChange:e=>E(e.currentTarget.value)})),f(h)&&r().createElement(c.Button,{icon:"plus",onClick:$},"New Simulation")),r().createElement("div",{className:i.grid},r().createElement("div",{className:i.column},w.length>0?w.map((e=>r().createElement(cn,{key:e.id,simulation:e,isSelected:(null==d?void 0:d.id)===e.id,onClick:x}))):r().createElement("div",{className:i.centerMessage,style:{height:"auto",marginTop:40}},r().createElement("p",null,'No results match "',v,'"'))),r().createElement("div",{className:i.column},d?r().createElement("div",{className:`${i.rightColumn}`},r().createElement(sn,{key:d.id,simulation:d,twinId:e,isEditor:f(h),onSuccess:()=>p(void 0)})):r().createElement("div",{className:`${i.placeholder} ${i.centerContent}`},r().createElement(c.Icon,{name:"info-circle",size:"xl",style:{marginTop:"10px",opacity:.6}}),r().createElement("p",{style:{opacity:.6}}," Select a simulation from the list to view details and execute.")))))},pn=e=>({container:l.css`
      display: flex;
      gap: ${e.spacing(3)};
      flex-wrap: wrap;
      width: 100%;
      align-items: flex-start;
    `,columnCard:l.css`
      background-color: ${e.colors.background.secondary};
      border: 1px solid ${e.colors.border.weak};
      border-radius: ${e.shape.borderRadius(2)};
      padding: ${e.spacing(2)};
      flex: 1;
      min-width: 350px; /* Un poco más ancho para acomodar el grid de 180px */
      box-shadow: ${e.shadows.z1};
    `,sectionHeader:l.css`
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      border-bottom: 2px solid ${e.colors.border.weak};
      padding-bottom: ${e.spacing(1)};
      margin-bottom: ${e.spacing(2)};
    `,titleText:l.css`
      margin: 0;
      font-size: ${e.typography.h4.fontSize};
      font-weight: ${e.typography.fontWeightBold};
      color: ${e.colors.text.primary};
    `,subTitleText:l.css`
      font-size: ${e.typography.bodySmall.fontSize};
      color: ${e.colors.text.secondary};
      text-transform: uppercase;
      letter-spacing: 0.5px;
    `,searchContainer:l.css`
      margin-bottom: ${e.spacing(2)};
    `,featureCard:l.css`
      background-color: ${e.colors.background.primary};
      border: 1px solid ${e.colors.border.weak};
      border-radius: ${e.shape.borderRadius()};
      margin-bottom: ${e.spacing(2)};
      overflow: hidden;
    `,featureHeader:l.css`
      background-color: ${e.colors.contrastThreshold};
      padding: ${e.spacing(1,1.5)};
      border-bottom: 1px solid ${e.colors.border.weak};
      font-weight: ${e.typography.fontWeightMedium};
      font-size: ${e.typography.body.fontSize};
      color: ${e.colors.text.primary};
      display: flex;
      align-items: center;
      gap: ${e.spacing(1)};
    `,propertiesGrid:l.css`
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: ${e.spacing(1.5)};
      padding: ${e.spacing(1.5)};
    `,kvContainer:l.css`
      display: flex;
      flex-direction: column;
    `,kvLabel:l.css`
      font-size: 11px;
      color: ${e.colors.text.secondary};
      text-transform: uppercase;
      margin-bottom: 2px;
    `,kvValue:l.css`
      font-size: 13px;
      color: ${e.colors.text.primary};
      font-weight: 500;
      word-break: break-all;
      line-height: 1.4;
    `,parentLink:l.css`
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background-color: ${e.colors.action.selected};
      color: ${e.colors.primary.text};
      border: 1px solid ${e.colors.primary.border};
      padding: 4px 10px;
      border-radius: 16px;
      font-size: 12px;
      text-decoration: none;
      transition: all 0.2s ease-in-out;
      margin-right: 6px;
      margin-bottom: 4px;
      cursor: pointer;

      &:hover {
        background-color: ${e.colors.primary.main};
        color: ${e.colors.primary.contrastText};
        text-decoration: none;
        transform: translateY(-1px);
        box-shadow: ${e.shadows.z1};
      }
    `});function un(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function mn({thingInfo:e,isType:t=!1}){const n=(0,c.useStyles2)(pn),[i,l]=(0,a.useState)(""),s=(0,o.useHistory)(),{url:d}=(0,o.useRouteMatch)(),p=t?"types":"twins",u=d.split(`/${p}`)[0]+`/${p}`,m=(e,t)=>null==t?"-":st.includes(e)?r().createElement("div",{style:{display:"flex",flexWrap:"wrap",marginTop:"4px"}},r().createElement("div",{onClick:()=>{return e=t,void s.push(`${u}/${e}`);var e},className:n.parentLink,role:"button",tabIndex:0,title:`Go to twin: ${t}`},r().createElement(c.Icon,{name:"cube",size:"xs"}),r().createElement("span",null,t))):"boolean"==typeof t?t?"True":"False":"object"==typeof t?JSON.stringify(t):String(t),g=({label:e,value:t,renderKey:a})=>r().createElement("div",{className:n.kvContainer},r().createElement("span",{className:n.kvLabel},dt(e)),r().createElement("div",{className:n.kvValue},m(a||e,t)));return r().createElement("div",{className:n.container},r().createElement("div",{className:n.columnCard},r().createElement("div",{className:n.sectionHeader},r().createElement("h3",{className:n.titleText},"Attributes"),r().createElement("span",{className:n.subTitleText},"Static Data")),(()=>{var a,o;let i=function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){un(e,t,n[t])}))}return e}({},ct(e,"attributes",{}));t&&delete i._parents;for(let e in i){const t=e.startsWith("_")&&"_parents"!==e;i.hasOwnProperty(e)&&(t||it.includes(e))&&delete i[e]}return r().createElement("div",{className:n.propertiesGrid,style:{gridTemplateColumns:"1fr"}},r().createElement(g,{label:"Name",value:null===(a=e.attributes)||void 0===a?void 0:a.name}),r().createElement(g,{label:"Description",value:null===(o=e.attributes)||void 0===o?void 0:o.description}),r().createElement(g,{label:"Policy ID",value:e.policyId}),i._parents&&r().createElement(g,{label:"Inheritance (Parents)",value:i._parents,renderKey:"_parents"}),Object.keys(i).map((e=>["name","description","_parents"].includes(e)?null:r().createElement(g,{key:e,label:e,value:i[e]}))))})()),r().createElement("div",{className:n.columnCard},r().createElement("div",{className:n.sectionHeader},r().createElement("h3",{className:n.titleText},"Features"),r().createElement("span",{className:n.subTitleText},"Dynamic Data")),r().createElement("div",{className:n.searchContainer},r().createElement(c.Input,{value:i,onChange:e=>l(e.currentTarget.value),placeholder:"Filter features...",prefix:r().createElement(c.Icon,{name:"search"})})),(()=>{const t=ct(e,"features",{}),a=Object.keys(t),o=a.filter((e=>{if(!i)return!0;const n=i.toLowerCase(),a=t[e],r=a.properties||a;return!!e.toLowerCase().includes(n)||!!r&&Object.entries(r).some((([e,t])=>{const a=null!=t?String(t):"";return e.toLowerCase().includes(n)||a.toLowerCase().includes(n)}))}));return 0===a.length?r().createElement("div",{className:n.kvValue,style:{padding:"10px"}},"No dynamic features available."):0===o.length?r().createElement("div",{className:n.kvValue,style:{padding:"10px",fontStyle:"italic"}},"No features match your search."):r().createElement("div",null,o.map((e=>{const a=t[e],o=a.properties||a,i=o&&Object.keys(o).length>0;return r().createElement("div",{key:e,className:n.featureCard},r().createElement("div",{className:n.featureHeader},r().createElement(c.Icon,{name:"bolt",size:"sm",style:{opacity:.7}}),r().createElement("span",null,e)),r().createElement("div",{className:n.propertiesGrid},i?Object.keys(o).map((e=>r().createElement(g,{key:e,label:e,value:o[e]}))):r().createElement("span",{className:n.kvLabel},"No data")))})))})()))}const gn=e=>{const t=`1px solid ${e.colors.border.weak}`,n=e.colors.background.elevated;return{container:l.css`
    width: 100%;
  `,loadingContainer:l.css`
    display: flex; justify-content: center; width: 100%; margin: ${e.spacing(4)} 0;
  `,searchContainer:l.css`
        flex-grow: 1;
        max-width: 400px;
    `,emptyContainer:l.css`
    display: flex; flex-direction: column; align-items: center; justify-content: center; margin-top: ${e.spacing(4)};
  `,toolbar:l.css`
    border-bottom: 1px solid ${e.colors.border.weak};
    padding-bottom: ${e.spacing(1)};
  `,switchSpacing:l.css`
      margin-right: ${e.spacing(2)} !important;
    `,cardWrapper:l.css`
    height: 100%;
    display: flex;
    flex-direction: column;
    background-color: ${n};
    border: ${t};
    border-radius: ${e.shape.borderRadius()};
    overflow: hidden;
    cursor: pointer;
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    &:hover {
      border-color: ${e.colors.primary.border};
      background-color: ${e.colors.background.primary};
      transform: translateY(-2px);
      box-shadow: ${e.shadows.z1};
    }
  `,imageContainer:l.css`
    height: 140px; 
    width: 100%; 
    position: relative;
    background-color: ${e.colors.background.canvas};
    border-bottom: ${t};
  `,image:l.css`
    height: 100%; width: 100%; object-fit: cover; object-position: center;
  `,parentBadge:l.css`
    position: absolute;
    top: 0; right: 0;
    background-color: rgba(0,0,0,0.6); // Fondo semitransparente
    color: ${e.colors.text.primary};
    padding: 2px 8px;
    font-size: ${e.typography.bodySmall.fontSize};
    border-bottom-left-radius: ${e.shape.borderRadius()};
    backdrop-filter: blur(2px);
  `,contentContainer:l.css`
    padding: ${e.spacing(1.5)};
    flex-grow: 1;
    display: flex;
    flex-direction: column;
  `,cardTitle:l.css`
    margin: 0;
    font-size: ${e.typography.h6.fontSize};
    font-weight: ${e.typography.fontWeightMedium};
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    color: ${e.colors.text.primary};
  `,cardId:l.css`
    margin: 0 0 ${e.spacing(1)} 0;
    font-size: ${e.typography.bodySmall.fontSize};
    color: ${e.colors.text.secondary};
    font-family: ${e.typography.fontFamilyMonospace};
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    opacity: 0.8;
  `,cardDescription:l.css`
    font-size: ${e.typography.bodySmall.fontSize};
    color: ${e.colors.text.secondary};
    // Truco CSS para limitar a 3 líneas y poner puntos suspensivos
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
    flex-grow: 1; // Empuja los botones hacia abajo
  `,cardActions:l.css`
    display: flex;
    justify-content: flex-end;
    align-items: center;
    padding: ${e.spacing(.5)} ${e.spacing(1)};
    border-top: ${t};
    background-color: ${e.colors.background.primary};
  `,compactCard:l.css`
    padding: ${e.spacing(1)};
    height: 100%;
    display: flex;
    flex-direction: column;
    cursor: pointer;
    justify-content: space-between;
    border: ${t};
    background-color: ${n};
    border-radius: ${e.shape.borderRadius()};
     &:hover {
      border-color: ${e.colors.primary.border};
      background-color: ${e.colors.background.primary};
      transform: translateY(-2px);
      box-shadow: ${e.shadows.z1};
    }
  `,linkReset:l.css`
    text-decoration: none; color: inherit; display: block; height: 100%;
    &:hover { text-decoration: none; color: inherit; }
  `,centerContent:l.css`
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: ${e.spacing(2)};
        padding: ${e.spacing(4)};
        text-align: center;
    `,loadMoreContainer:l.css`
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        margin-top: ${e.spacing(3)};
        margin-bottom: ${e.spacing(2)};
    `,paginationBar:l.css`
        display: flex;
        justify-content: center; // A la derecha o 'center' si prefieres centrado
        align-items: center;
        gap: ${e.spacing(2)};
        margin-bottom: ${e.spacing(2)};
        margin-top: ${e.spacing(2)};
        padding-bottom: ${e.spacing(1)};
    `,pageInfo:l.css`
        font-weight: 500;
        color: ${e.colors.text.secondary};
        font-size: ${e.typography.bodySmall.fontSize};
    `}},fn=({thing:e,isEditor:t,isCompact:n,styles:a,parentId:i,onDelete:l,isType:s,resourceRoot:d})=>{var p,u;const m=ct(e.attributes,"name",e.thingId||"").trim(),g=ct(e.attributes,"description",""),f=void 0!==(y=ct(e.attributes,"image",void 0))&&""!==y?y:"https://i.imgur.com/DhxyHBc.png";var y;const h=s&&i&&(null===(u=e.attributes)||void 0===u||null===(p=u._parents)||void 0===p?void 0:p[i])?e.attributes._parents[i]:null,b=(0,o.useHistory)(),v=`${d}/${e.thingId}`,E=`${d}/${e.thingId}/edit`,w=e=>{e.preventDefault(),b.push(v)},x=e=>{e.preventDefault(),b.push(E)};return n?r().createElement("div",{className:"col-6 col-sm-4 col-md-3 col-lg-2 mb-3"},r().createElement("div",{className:a.compactCard},r().createElement("div",{onClick:w,className:a.linkReset},r().createElement("div",null,r().createElement("h6",{className:a.cardTitle,style:{fontSize:"0.9rem"}},m),r().createElement("p",{className:a.cardId,style:{fontSize:"0.75rem"}},e.thingId))),t&&r().createElement("div",{style:{display:"flex",justifyContent:"flex-end",marginTop:"4px"}},r().createElement(c.LinkButton,{fill:"text",variant:"secondary",size:"sm",icon:"pen",tooltip:"Edit",onClick:x}),r().createElement(c.LinkButton,{fill:"text",variant:"destructive",size:"sm",icon:"trash-alt",tooltip:"Delete",onClick:t=>{t.preventDefault(),l(e.thingId)}})))):r().createElement("div",{className:"col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 mb-4"},r().createElement("div",{className:a.cardWrapper},r().createElement("div",{className:a.imageContainer},h&&r().createElement("div",{className:a.parentBadge},"x",h," children"),r().createElement("div",{onClick:w,className:a.linkReset},r().createElement("img",{src:f,className:a.image,alt:m,loading:"lazy"}))),r().createElement("div",{className:a.contentContainer},r().createElement("div",{onClick:w,className:a.linkReset},r().createElement("h5",{className:a.cardTitle},m),r().createElement("p",{className:a.cardId,title:e.thingId},e.thingId),r().createElement("p",{className:a.cardDescription},g))),t&&r().createElement("div",{className:a.cardActions},r().createElement(c.LinkButton,{fill:"text",variant:"secondary",size:"sm",icon:"pen",tooltip:"Edit",onClick:x}),r().createElement(c.LinkButton,{fill:"text",variant:"destructive",size:"sm",icon:"trash-alt",tooltip:"Delete",onClick:t=>{t.preventDefault(),l(e.thingId)}}))))};function yn(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function hn(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){yn(o,a,r,i,l,"next",e)}function l(e){yn(o,a,r,i,l,"throw",e)}i(void 0)}))}}function bn({isType:e,funcThings:t,funcDelete:n,funcDeleteChildren:d,parentId:p,iniCompactMode:g=!1,iniNoSimulations:y=!1}){const h=(0,c.useStyles2)(gn),b=(0,i.getAppEvents)(),v=(0,o.useHistory)(),{url:E}=(0,o.useRouteMatch)(),w=e?"types":"twins",x=`${E.split(`/${w}`)[0]}/${w}`,[$,O]=(0,a.useState)([]),[C,S]=(0,a.useState)([void 0]),[k,T]=(0,a.useState)(0),[P,N]=(0,a.useState)(void 0),[j,I]=(0,a.useState)(!1),[D,A]=(0,a.useState)(""),[R,L]=(0,a.useState)(""),[M,z]=(0,a.useState)(!0),[B,F]=(0,a.useState)(void 0),[q,G]=(0,a.useState)(!1),[U,_]=(0,a.useState)(g),[H,W]=(0,a.useState)(y),[J,K]=(0,a.useState)(u.VIEWER),V=e?"type":"twin",Y=f(J),Q=(0,a.useCallback)(((e,n)=>hn((function*(){z(!0);try{const a=yield t(e,12,n,p);let r,o=[];a&&"object"==typeof a&&"items"in a?(o=a.items,r=a.cursor):Array.isArray(a)&&(o=a),O(o),N(r),I(!!r)}catch(e){console.error(e),b.publish({type:s.AppEvents.alertError.name,payload:["Error fetching items"]})}finally{z(!1)}}))()),[t,b]);(0,a.useEffect)((()=>{const e=C[k];Q(e,R),m().then(K)}),[k,R,Q]);const X=(0,a.useMemo)((()=>{let e=$;return H&&(e=e.filter((e=>!e.attributes||!e.attributes[rt]))),e}),[$,H]),Z=(0,a.useMemo)((()=>$.some((e=>e.attributes&&e.attributes[rt]))),[$]),ee=()=>{if(j&&P){const e=[...C.slice(0,k+1),P];S(e),T(k+1)}},te=()=>{k>0&&T(k-1)},ne=()=>{S([void 0]),T(0),L(D)},ae=(e,t)=>hn((function*(){F(void 0),G(!0);const a=t&&d?d:n;try{yield a(e),b.publish({type:s.AppEvents.alertSuccess.name,payload:[`The ${V} has been deleted correctly.`]}),O((t=>t.filter((t=>t.thingId!==e))))}catch(e){console.error(e),b.publish({type:s.AppEvents.alertError.name,payload:[`The ${V} could not be deleted.`]})}finally{G(!1)}}))(),re=()=>{p?v.push(`${x}/${p}/new`):v.push(`${x}/new`)};return M&&0===$.length&&0===k?r().createElement("div",{className:h.loadingContainer},r().createElement(c.Spinner,{size:20})):M||0!==$.length||R||0!==k?r().createElement("div",{className:h.container},r().createElement("div",{className:(0,l.cx)("row justify-content-between align-items-center",h.toolbar)},r().createElement("div",{className:"col-12 col-md-9 mb-2 d-flex align-items-center flex-wrap"},r().createElement("div",{style:{flexGrow:1,maxWidth:"400px",marginRight:"20px"}},r().createElement(c.Input,{value:D,onChange:e=>A(e.currentTarget.value),onKeyDown:e=>{"Enter"===e.key&&ne()},prefix:r().createElement(c.Icon,{name:"search"}),suffix:r().createElement(c.Icon,{name:"arrow-right",style:{cursor:"pointer",opacity:D?1:.5},onClick:ne,title:"Press Enter to search"}),placeholder:"Search ID or Name..."})),r().createElement("div",{className:"d-flex align-items-center"},r().createElement(c.InlineSwitch,{value:U,onChange:()=>_(!U),label:"Compact",showLabel:!0,className:h.switchSpacing}),!e&&r().createElement(c.InlineSwitch,{value:!H,onChange:()=>W(!H),label:"Simulated",showLabel:!0,disabled:!Z,className:h.switchSpacing}))),r().createElement("div",{className:"col-12 col-md-3 mb-2 d-flex justify-content-end"},r().createElement(c.LinkButton,{icon:"plus",hidden:!Y,variant:"primary",onClick:re},"New ",V))),q&&r().createElement("div",{className:h.loadingContainer},r().createElement(c.Spinner,{inline:!0,size:20})),0===$.length&&0===k?null:r().createElement("div",{className:h.paginationBar},r().createElement(c.Button,{variant:"secondary",fill:"outline",size:"sm",icon:"arrow-left",onClick:te,disabled:0===k||M},"Previous"),r().createElement("span",{className:h.pageInfo},"Page ",k+1),r().createElement(c.Button,{variant:"secondary",fill:"outline",size:"sm",onClick:ee,disabled:!j||M},"Next ",r().createElement(c.Icon,{name:"arrow-right",style:{marginLeft:8}}))),M?r().createElement("div",{className:h.loadingContainer},r().createElement(c.Spinner,{size:32})):r().createElement("div",{className:"row"},X.length>0?X.map((t=>r().createElement(fn,{key:t.thingId,thing:t,isEditor:Y,isCompact:U,styles:h,parentId:p,isType:e,onDelete:e=>F(e),resourceRoot:x}))):r().createElement("div",{className:h.loadingContainer},r().createElement("h5",null,'No items found matching "',R,'"'))),!!B&&r().createElement(c.ConfirmModal,{isOpen:!0,title:`Delete ${V}`,body:`Are you sure you want to remove the ${V} with id ${B}?`,description:!e&&d?"Choose removal type.":void 0,confirmText:!e&&d?"With children":"Delete",alternativeText:!e&&d?"Without children":void 0,dismissText:"Cancel",onConfirm:()=>ae(B,!0),onAlternative:!e&&d?()=>ae(B,!1):void 0,onDismiss:()=>F(void 0)})):r().createElement("div",{className:h.centerContent},r().createElement("h3",null,"No ",V,"s found"),r().createElement("p",null,p?`There are no children configured for this ${V} yet.`:`There are no ${V}s`),r().createElement(c.LinkButton,{icon:"plus",hidden:!Y,variant:"primary",onClick:re},"New ",V))}var vn=function(e){return e.ACTIVE="Active",e.PAUSED="Paused",e}({});const En=[{label:"All",value:"all"},{label:"Deploy",value:"deployment"},{label:"CronJob",value:"cronjob"}];function wn(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function xn(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){wn(o,a,r,i,l,"next",e)}function l(e){wn(o,a,r,i,l,"throw",e)}i(void 0)}))}}const $n=(e,t)=>xn((function*(){return yield te(`${Q}/agent/${t}/${e}/pause`,{method:"POST"})}))(),On=(e,t)=>xn((function*(){return yield te(`${Q}/agent/${t}/${e}/resume`,{method:"POST"})}))();function Cn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function Sn(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const kn=e=>{const t=(0,a.useContext)(Ve),n=(0,i.getAppEvents)(),r=(0,o.useHistory)(),l=(0,o.useLocation)(),[c,d]=(0,a.useState)([]),[p,g]=(0,a.useState)([]),[f,y]=(0,a.useState)(void 0),[h,b]=(0,a.useState)(gt.READY),[v,E]=(0,a.useState)({search:"",type:En[0]}),[w,x]=(0,a.useState)([]),[$,O]=(0,a.useState)(u.VIEWER),[C,S]=(0,a.useState)([]),[k,T]=(0,a.useState)(!1),P=l.pathname.split("/agents")[0].split("/twins")[0],N=()=>{c.length<1&&b(gt.LOADING),((e,t)=>xn((function*(){const n=new URLSearchParams;e.agent_context&&""!==e.agent_context.trim()&&n.append("context",e.agent_context),t&&n.append("twin",t);const a=n.toString(),r=a?`${Q}/agents?${a}`:`${Q}/agents`;return yield te(r,{method:"GET"})}))())(t,e).then((e=>{const t=e.sort(((e,t)=>(e.namespace+e.id).localeCompare(t.namespace+t.id)));if(d(t),b(gt.READY),f){const t=e.find((e=>e.id===f.id));t&&y((e=>e?Sn(function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){Cn(e,t,n[t])}))}return e}({},e),{info:t}):void 0))}})).catch((e=>{console.error(e),n.publish({type:s.AppEvents.alertError.name,payload:["Error getting agents"]})}))},j=e=>{var t,a;(t=e.id,a=e.namespace,xn((function*(){return yield te(`${Q}/agent/${a}/${t}`,{method:"GET"})}))()).then((t=>{t&&y({id:e.id,info:e,data:JSON.parse(t)})})).catch((e=>{n.publish({type:s.AppEvents.alertError.name,payload:["Error getting agent details"]})}))};return(0,a.useEffect)((()=>{N(),$t().then((e=>x(e.map((e=>({value:e,label:e})))))),m().then((e=>O(e)));const e=setInterval(N,1e4);return()=>clearInterval(e)}),[]),(0,a.useEffect)((()=>{let e=[...c];if(v.search){const t=v.search.toLowerCase();e=e.filter((e=>e.id.toLowerCase().includes(t)||e.name.toLowerCase().includes(t)||e.namespace.toLowerCase().includes(t)))}v.type.value&&"all"!==v.type.value&&(e=e.filter((e=>e.type===v.type.value))),g(e)}),[c,v]),(0,a.useEffect)((()=>{f&&S(Array(f.info.pods.length).fill(void 0))}),[null==f?void 0:f.id]),{agents:p,selectedAgent:f,loadingState:h,filters:v,twins:w,userRole:$,latestLogs:C,isLogLoading:k,hasAgents:c.length>0,setFilters:E,setSelectedAgent:e=>{e&&(null==f?void 0:f.id)!==e.id?j(e):y(void 0)},handleNavigateToCreate:()=>{const t=e?`${P}/twins/${e}/agents/new`:`${P}/agents/new`;r.push(t)},handleNavigateToTwin:e=>{r.push(`${P}/twins/${e}`)},handlePausePlay:e=>{(e.status===vn.ACTIVE?$n:On)(e.id,e.namespace).then(N).catch((()=>{n.publish({type:s.AppEvents.alertError.name,payload:["Error changing agent state"]})}))},handleDelete:e=>{return(t=e.id,a=e.namespace,xn((function*(){return yield te(`${Q}/agent/${a}/${t}`,{method:"DELETE"})}))()).then((()=>{N(),y(void 0),n.publish({type:s.AppEvents.alertSuccess.name,payload:["Agent deleted"]})}));var t,a},handleLinkTwins:(e,t,a)=>{const r=a.map((n=>((e,t,n)=>xn((function*(){return yield te(`${Q}/agent/${n}/${e}/twin/${t}/link`,{method:"PUT"})}))())(e,n,t)));Promise.all(r).then((()=>{n.publish({type:s.AppEvents.alertSuccess.name,payload:["Twins linked"]}),N()})).catch((e=>{n.publish({type:s.AppEvents.alertError.name,payload:["Error linking twins"]})}))},handleUnlinkTwin:(e,t,a)=>{((e,t,n)=>xn((function*(){return yield te(`${Q}/agent/${n}/${e}/twin/${t}/unlink`,{method:"PUT"})}))())(e,a,t).then((()=>{n.publish({type:s.AppEvents.alertSuccess.name,payload:["Twin unlinked"]}),N()}))},fetchLog:(e,t)=>{T(!0),(e=>xn((function*(){return yield te(`${Q}/agents/${e}/logs`,{method:"GET"})}))())(e).then((e=>{const n=[...C];n[t]={timestamp:Date.now(),text:e},S(n)})).finally((()=>T(!1)))}}},Tn=e=>r().createElement("svg",{height:20,viewBox:"0 0 512 512.44",shapeRendering:"geometricPrecision",textRendering:"geometricPrecision",imageRendering:"optimizeQuality",fillRule:"evenodd",clipRule:"evenodd",xmlns:"http://www.w3.org/2000/svg"},r().createElement("path",{fill:e,fillRule:"nonzero",d:"M216.81 155.94c0-10.96 8.88-19.84 19.84-19.84 10.95 0 19.83 8.88 19.83 19.84v120.75l82.65 36.33c10.01 4.41 14.56 16.1 10.15 26.11-4.41 10.02-16.1 14.56-26.11 10.15l-93.5-41.1c-7.51-2.82-12.86-10.07-12.86-18.57V155.94zM9.28 153.53c-.54-1.88-.83-3.87-.83-5.92l.16-73.41c0-11.84 9.59-21.43 21.43-21.43 11.83 0 21.43 9.59 21.43 21.43l-.06 27.86a255.053 255.053 0 0144.08-45.53c16.78-13.47 35.57-25.04 56.18-34.24 64.6-28.81 134.7-28.73 195.83-5.31 60.67 23.24 112.56 69.47 141.51 133.25.56 1.01 1.03 2.07 1.41 3.17 28.09 64.15 27.83 133.6 4.6 194.21-22.33 58.29-65.87 108.46-125.8 137.98-.38.22-.76.42-1.16.62-12.44 6.14-25.46 11.26-38.74 15.3-4.96 1.46-10.12.99-14.68-1.46-15.1-8.13-12.86-30.46 3.53-35.45 8.78-2.7 17.32-5.87 25.67-9.6.41-.21.84-.4 1.27-.58 2-.91 3.99-1.85 5.96-2.82.53-.26 1.07-.5 1.62-.71 50.62-25.1 87.42-67.61 106.34-116.98 19.93-52.04 20.04-111.64-4.41-166.46l-.01-.02c-24.46-54.82-68.84-94.54-120.82-114.45-52.04-19.94-111.63-20.04-166.45 4.41a217.791 217.791 0 00-47.75 29.11 216.133 216.133 0 00-37.71 39.04l17.1-.97c11.83-.65 21.96 8.42 22.61 20.26.65 11.83-8.42 21.96-20.26 22.61l-69.71 3.94c-11.02.6-20.56-7.21-22.34-17.85zm237.66 358.9c17.55.55 26.69-20.55 14.26-32.98-3.57-3.45-7.9-5.35-12.86-5.56-11.92-.39-23.48-1.72-35.19-4.01-7.52-1.44-14.84 1.44-19.39 7.59-8.15 11.46-1.97 27.43 11.85 30.22a256.37 256.37 0 0041.33 4.74zm-119.12-34.22c11.75 6.79 26.54-.08 28.81-13.5 1.23-7.97-2.34-15.6-9.26-19.74-10.27-5.99-19.83-12.71-28.99-20.28-13.76-11.34-34.16.32-31.36 17.95.81 4.7 3.05 8.59 6.69 11.68a255.166 255.166 0 0034.11 23.89zm-88.67-86.32c8.88 14.11 30.17 11.17 34.88-4.84 1.51-5.36.76-10.83-2.17-15.57-6.29-10.03-11.7-20.52-16.31-31.43-6.2-14.74-26.7-15.97-34.56-2.04-2.94 5.15-3.3 11.48-1 16.94 5.36 12.77 11.8 25.21 19.16 36.94zM.66 274.2c.62 8.63 6.81 15.71 15.27 17.51 12.64 2.53 23.99-7.36 23.19-20.23-.85-11.87-.73-23.54.32-35.4.59-7.04-2.49-13.66-8.31-17.67-12.22-8.25-28.69-.5-30.08 14.17a257.06 257.06 0 00-.39 41.62z"})),Pn=e=>r().createElement("svg",{height:20,version:"1.1",id:"Layer_1",xmlns:"http://www.w3.org/2000/svg",x:"0px",y:"0px",viewBox:"0 0 122.88 120.81"},r().createElement("g",null,r().createElement("path",{fill:e,d:"M15.44,85.83c1.26-0.98,3.08-0.75,4.06,0.51c0.98,1.26,0.75,3.08-0.51,4.06l-13.1,10.17l-0.1,13.39l15.78-0.88l8.73-13.87 c0.85-1.35,2.63-1.75,3.98-0.9c1.35,0.85,1.75,2.63,0.9,3.98l-9.47,15.05c-0.47,0.81-1.33,1.37-2.34,1.43L3.04,119.9l0,0 c-0.06,0-0.11,0-0.17,0c-1.59-0.01-2.88-1.3-2.87-2.89l0.13-17.65c-0.07-0.93,0.32-1.88,1.11-2.5L15.44,85.83L15.44,85.83z M40.28,53.81c6.59-19.69,15.46-33.64,27.95-42.44C81.2,2.25,97.86-1.21,119.69,0.37c1.51,0.11,2.66,1.35,2.69,2.83 c2.11,23.64-2.47,40.4-12.25,53.1C100.71,68.51,86.6,76.77,69.07,83.7v23.07c0,1.13-0.65,2.11-1.6,2.59l-17.84,11.02 c-1.35,0.84-3.13,0.42-3.97-0.94c-0.22-0.36-0.36-0.75-0.41-1.14l0,0c-3.95-30.19-8.15-31.64-32.83-40.18 C9.48,77.1,6.29,76,4.14,75.24c-1.5-0.53-2.29-2.18-1.76-3.69c0.11-0.32,0.28-0.61,0.48-0.86l11.76-16.77 c0.59-0.84,1.54-1.27,2.5-1.23v0L40.28,53.81L40.28,53.81z M84.68,25.72c3.36,0,6.4,1.36,8.6,3.56c2.2,2.2,3.56,5.24,3.56,8.6 c0,3.36-1.36,6.4-3.56,8.6c-2.2,2.2-5.24,3.56-8.6,3.56c-3.36,0-6.4-1.36-8.6-3.56c-2.2-2.2-3.56-5.24-3.56-8.6 c0-3.36,1.36-6.4,3.56-8.6C78.28,27.08,81.32,25.72,84.68,25.72L84.68,25.72z M90.48,32.08c-1.48-1.48-3.53-2.4-5.8-2.4 c-2.26,0-4.31,0.92-5.8,2.4c-1.48,1.48-2.4,3.53-2.4,5.8c0,2.26,0.92,4.31,2.4,5.8c1.48,1.48,3.53,2.4,5.8,2.4 c2.26,0,4.31-0.92,5.8-2.4c1.48-1.48,2.4-3.53,2.4-5.8C92.88,35.61,91.96,33.56,90.48,32.08L90.48,32.08z M71.55,16.1 c-11.81,8.32-20.18,21.94-26.43,41.43c-0.34,1.29-1.54,2.22-2.93,2.15l-23.77-1.16L9.64,71.05c1.86,0.65,3.29,1.15,4.66,1.62 c26.32,9.1,31.79,10.99,36.07,40.47l12.91-7.97V81.74h0.01c0-1.16,0.71-2.25,1.85-2.69c17.46-6.72,31.41-14.6,40.41-26.28 c8.59-11.15,12.75-25.95,11.26-46.79C97.58,4.92,82.89,8.13,71.55,16.1L71.55,16.1z"}))),Nn=({agent:e,isSelected:t,onClick:n,onPause:a,onDelete:o,canEdit:i})=>{const s=(0,c.useStyles2)(jn),d=e.status===vn.ACTIVE;return r().createElement("div",{className:(0,l.cx)(s.card,t&&s.selectedCard),onClick:()=>n(e)},r().createElement("div",{className:s.topRow},r().createElement("div",{className:s.iconArea},"deployment"===e.type?Pn(s.iconColor):Tn(s.iconColor)),r().createElement("div",{className:s.titleArea},r().createElement("div",{className:s.name},e.name),r().createElement("div",{className:s.namespace},e.namespace)),i&&r().createElement("div",{className:s.actions,onClick:e=>e.stopPropagation()},r().createElement(c.IconButton,{name:d?"pause":"play",size:"sm",onClick:()=>a(e),tooltip:d?"Pause":"Resume"}),r().createElement(c.IconButton,{name:"trash-alt",size:"sm",variant:"destructive",onClick:()=>o(e),tooltip:"Delete"}))),r().createElement("div",{className:s.infoRow},r().createElement("div",{className:s.statusBadge,style:{color:d?"#73BF69":"#FF9830"}},r().createElement(c.Icon,{name:d?"heart":"pause",size:"sm"}),r().createElement("span",null,e.status)),r().createElement("div",{className:s.metrics},r().createElement("span",null,"Pods: ",r().createElement("b",null,e.pods.length)))))},jn=e=>({card:l.css`
        background-color: ${e.colors.background.elevated};
        border: 1px solid ${e.colors.border.weak};
        border-radius: ${e.shape.borderRadius()};
        padding: ${e.spacing(1.5)}; /* Padding reducido */
        cursor: pointer;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        min-height: 100px; /* Altura compacta */
        position: relative;

        &:hover {
            border-color: ${e.colors.primary.border};
            background-color: ${e.colors.background.primary};
            transform: translateY(-2px);
            box-shadow: ${e.shadows.z1};
        }
    `,selectedCard:l.css`
        border-color: ${e.colors.primary.main};
        background-color: ${e.colors.action.selected};
        &:hover {
            background-color: ${e.colors.action.selected};
        }
    `,topRow:l.css`
        display: flex;
        align-items: flex-start;
        gap: ${e.spacing(1.5)};
        margin-bottom: ${e.spacing(1)};
    `,iconArea:l.css`
        margin-top: 2px;
        opacity: 0.9;
    `,iconColor:e.colors.text.primary,titleArea:l.css`
        flex: 1;
        overflow: hidden;
    `,name:l.css`
        font-size: ${e.typography.h6.fontSize};
        font-weight: ${e.typography.fontWeightMedium};
        color: ${e.colors.text.primary};
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    `,namespace:l.css`
        font-size: ${e.typography.bodySmall.fontSize};
        color: ${e.colors.text.secondary};
        font-family: ${e.typography.fontFamilyMonospace};
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    `,actions:l.css`
        display: flex;
        gap: 2px;
    `,infoRow:l.css`
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: ${e.typography.bodySmall.fontSize};
        border-top: 1px solid ${e.colors.border.weak};
        padding-top: ${e.spacing(1)};
        margin-top: auto; /* Empuja esto al fondo */
    `,statusBadge:l.css`
        display: flex;
        align-items: center;
        gap: 6px;
        font-weight: 500;
        text-transform: uppercase;
        font-size: 10px;
    `,metrics:l.css`
        color: ${e.colors.text.secondary};
    `}),In=({agent:e,twins:t,latestLogs:n,isLoadingLog:o,canEdit:i,onLoadLog:l,onLinkTwins:s,onUnlinkTwin:d,onNavigateTwin:p,onClose:u})=>{const m=(0,c.useStyles2)(Dn),[g,f]=(0,a.useState)(0),[y,h]=(0,a.useState)([]),b=t.filter((t=>!e.info.twins.includes(t.value))),v="cronjob"===e.info.type;return r().createElement("div",{className:m.container},r().createElement("div",{className:m.header},r().createElement("div",{className:m.headerTop},r().createElement("div",{className:m.typeBadge},r().createElement("span",null,e.info.type.toUpperCase()))),r().createElement("div",{className:m.titleRow},r().createElement("div",{className:m.bigIcon},v?Tn(m.iconColor):Pn(m.iconColor)),r().createElement("div",{className:m.titleContent},r().createElement("h2",{className:m.title},e.info.name),r().createElement("div",{className:m.subtitle},r().createElement("span",{className:m.namespace},e.info.namespace),r().createElement("span",{className:m.separator},"/"),r().createElement("span",{className:m.id},e.info.id)))),r().createElement("div",{className:m.statusRow},r().createElement(c.Badge,{text:e.info.status,color:"Active"===e.info.status?"green":"orange"}))),r().createElement("div",{className:m.tabsContainer},r().createElement(c.TabsBar,null,r().createElement(c.Tab,{label:"Overview",active:0===g,onChangeTab:()=>f(0)}),r().createElement(c.Tab,{label:"Pods & Logs",active:1===g,onChangeTab:()=>f(1),counter:e.info.pods.length}),r().createElement(c.Tab,{label:"Definition",active:2===g,onChangeTab:()=>f(2)}))),r().createElement(c.CustomScrollbar,{autoHeightMin:"100%"},r().createElement("div",{className:m.content},0===g&&r().createElement("div",{className:m.section},r().createElement("h4",{className:m.sectionTitle},"Digital Twins"),r().createElement("div",{className:m.twinList},0===e.info.twins.length&&r().createElement("div",{className:m.emptyText},"No twins linked yet."),e.info.twins.map((e=>r().createElement("div",{key:e,className:m.twinItem},r().createElement("div",{className:m.twinIcon},r().createElement(c.Icon,{name:"arrow-random"})),r().createElement(c.LinkButton,{fill:"text",variant:"primary",onClick:()=>p(e)},e),i&&r().createElement(c.IconButton,{"aria-labelledby":"",name:"trash-alt",size:"sm",variant:"secondary",onClick:()=>d(e)}))))),i&&r().createElement("div",{className:m.linkBox},r().createElement(c.MultiSelect,{options:b,value:y,onChange:h,placeholder:"Link new twins..."}),r().createElement(c.Button,{disabled:0===y.length,onClick:()=>{s(y.map((e=>e.value))),h([])},variant:"secondary",style:{marginTop:8},fullWidth:!0},"Link Selected Twins"))),1===g&&r().createElement("div",{className:m.section},e.info.pods.map(((e,t)=>r().createElement("div",{key:e.id,className:m.podCard},r().createElement("div",{className:m.podHeader},r().createElement("div",{className:m.podStatus,style:{backgroundColor:"Running"===e.phase?"#73BF69":"#F2495C"}}),r().createElement("div",{style:{flex:1,fontWeight:500}},e.id),r().createElement("div",{style:{fontSize:11,color:"#888"}},e.phase)),r().createElement("div",{className:m.podActions},r().createElement(c.Button,{size:"sm",variant:"secondary",fill:"outline",icon:o?"spinner":"file-alt",onClick:()=>l(e.podId,t),fullWidth:!0},n[t]?"Refresh Logs":"Load Logs")),n[t]&&r().createElement("div",{className:m.consoleBox},r().createElement("div",{className:m.consoleHeader},"Last update: ",new Date(n[t].timestamp).toLocaleTimeString()),r().createElement(c.TextArea,{className:m.consoleText,readOnly:!0,value:n[t].text,rows:10})))))),2===g&&r().createElement("div",{className:m.section},r().createElement(c.TextArea,{className:m.consoleText,readOnly:!0,value:JSON.stringify(e.data,null,2),rows:30})))))},Dn=e=>({container:l.css`
        display: flex;
        flex-direction: column;
        background-color: ${e.colors.background.primary};
    `,header:l.css`
        padding: ${e.spacing(3)};
        background: ${e.colors.background.primary};
        border-bottom: 1px solid ${e.colors.border.weak};
    `,headerTop:l.css`
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: ${e.spacing(2)};
    `,typeBadge:l.css`
        display: flex;
        align-items: center;
        gap: ${e.spacing(1)};
        font-size: 11px;
        font-weight: 600;
        color: ${e.colors.text.secondary};
        letter-spacing: 1px;
    `,titleRow:l.css`
        display: flex;
        gap: ${e.spacing(2)};
        align-items: center;
        margin-bottom: ${e.spacing(2)};
        margin-left: ${e.spacing(1)};
    `,bigIcon:l.css`
        transform: scale(1.5);
        opacity: 0.9;
    `,iconColor:e.colors.text.primary,titleContent:l.css`
        overflow: hidden;
    `,title:l.css`
        margin: 0;
        font-size: ${e.typography.h3.fontSize};
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    `,subtitle:l.css`
        display: flex;
        align-items: center;
        font-family: ${e.typography.fontFamilyMonospace};
        font-size: ${e.typography.bodySmall.fontSize};
    `,namespace:l.css`color: ${e.colors.text.primary};`,separator:l.css`margin: 0 4px; color: ${e.colors.text.disabled};`,id:l.css`color: ${e.colors.text.secondary};`,statusRow:l.css`
        display: flex;
        align-items: center;
        gap: ${e.spacing(2)};
    `,cronText:l.css`
        font-size: 12px;
        color: ${e.colors.text.secondary};
        display: flex;
        align-items: center;
        gap: 6px;
    `,tabsContainer:l.css`
        padding: 0 ${e.spacing(2)};
        border-bottom: 1px solid ${e.colors.border.weak};
    `,content:l.css`
        padding: ${e.spacing(3)};
    `,section:l.css`
        margin-bottom: ${e.spacing(3)};
    `,sectionTitle:l.css`
        margin-bottom: ${e.spacing(2)};
        color: ${e.colors.text.secondary};
        text-transform: uppercase;
        font-size: 12px;
        font-weight: 600;
    `,twinList:l.css`
        display: flex;
        flex-direction: column;
        gap: ${e.spacing(1)};
        margin-bottom: ${e.spacing(2)};
    `,twinItem:l.css`
        display: flex;
        align-items: center;
        gap: ${e.spacing(1)};
        padding: ${e.spacing(1)};
        border: 1px solid ${e.colors.border.weak};
        border-radius: ${e.shape.borderRadius()};
        background: ${e.colors.background.secondary};
    `,twinIcon:l.css`color: ${e.colors.text.secondary};`,emptyText:l.css`color: ${e.colors.text.disabled}; font-style: italic;`,linkBox:l.css`
        border-top: 1px dashed ${e.colors.border.weak};
        padding-top: ${e.spacing(2)};
    `,podCard:l.css`
        border: 1px solid ${e.colors.border.weak};
        border-radius: ${e.shape.borderRadius()};
        margin-bottom: ${e.spacing(2)};
        overflow: hidden;
    `,podHeader:l.css`
        display: flex;
        align-items: center;
        padding: ${e.spacing(1)};
        background: ${e.colors.background.secondary};
        gap: ${e.spacing(1.5)};
        border-bottom: 1px solid ${e.colors.border.weak};
    `,podStatus:l.css`
        width: 8px;
        height: 8px;
        border-radius: 50%;
    `,podActions:l.css`
        padding: ${e.spacing(1)};
    `,consoleBox:l.css`
        border-top: 1px solid ${e.colors.border.weak};
    `,consoleHeader:l.css`
        padding: 4px 8px;
        font-size: 10px;
        color: ${e.colors.text.secondary};
        background: ${e.colors.background.primary};
        border-bottom: 1px solid ${e.colors.border.weak};
        text-align: right;
    `,consoleText:l.css`
        font-family: ${e.typography.fontFamilyMonospace};
        font-size: 12px;
        border: none;
        background: ${e.colors.background.primary};
    `}),An=e=>({wrapper:l.css`
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
        gap: ${e.spacing(2)};
    `,loadingContainer:l.css`
        display: flex;
        justify-content: center;
        padding-top: 100px;
    `,toolbar:l.css`
        display: flex;
        gap: ${e.spacing(2)};
        padding-bottom: ${e.spacing(2)};
        border-bottom: 1px solid ${e.colors.border.weak};
        flex-shrink: 0;
        align-items: center;
    `,searchContainer:l.css`
        flex-grow: 1;
        max-width: 400px;
    `,splitLayout:l.css`
        display: grid;
        /* Aquí definimos el 2/3 vs 1/3 */
        grid-template-columns: 2fr 1fr;
        gap: ${e.spacing(2)};
        overflow: hidden; /* Importante para que el scroll sea interno */
        
        /* Responsive: Si la pantalla es pequeña (< 1000px), apilamos en 1 columna */
        @media (max-width: 1000px) {
            grid-template-columns: 1fr;
            overflow-y: auto; /* Scroll global en móvil */
        }
    `,leftColumn:l.css`
        display: flex;
        flex-direction: column;
        overflow-y: auto; /* Scroll independiente */
        padding-right: ${e.spacing(1)};

        /* Scrollbar styling */
        &::-webkit-scrollbar { width: 6px; }
        &::-webkit-scrollbar-thumb { background: ${e.colors.action.disabledBackground}; border-radius: 3px; }
        &::-webkit-scrollbar-track { background: transparent; }
    `,cardsGrid:l.css`
        display: grid;
        /* Las tarjetas se adaptan al espacio disponible (2/3 de la pantalla) */
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: ${e.spacing(1.5)};
        padding-bottom: ${e.spacing(2)};
        padding-top: ${e.spacing(.5)};
    `,rightColumn:l.css`
        display: flex;
        flex-direction: column;
        overflow-y: auto;
        background-color: ${e.colors.background.primary};
        border: 1px solid ${e.colors.border.weak};
        border-radius: ${e.shape.borderRadius()};
        position: relative;
        min-height: 0; /* Fix para flex items overflow */

        /* En móvil, le damos una altura mínima si se apila */
        @media (max-width: 1000px) {
            min-height: 400px;
        }
    `,detailsContent:l.css`
        flex: 1;
        /* Si AgentDetails no tiene padding interno, descomentar abajo */
        /* padding: ${e.spacing(2)}; */
    `,centerContent:l.css`
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: ${e.spacing(2)};
        padding: ${e.spacing(4)};
        text-align: center;
    `,centerMessage:l.css`
        display: flex;
        justify-content: center;
        align-items: center;
        color: ${e.colors.text.secondary};
        opacity: 0.7;
    `,placeholderContainer:l.css`
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        padding: ${e.spacing(3)};
    `,placeholderContent:l.css`
        text-align: center;
        color: ${e.colors.text.secondary};
        opacity: 0.6;
        height: 100%;
        align-content: center;
        max-width: 250px;
        
        h4 {
            margin-bottom: ${e.spacing(1)};
            color: ${e.colors.text.primary};
        }
    `});function Rn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function Ln(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){Rn(e,t,n[t])}))}return e}function Mn(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}function zn({twinId:e}){const t=(0,c.useStyles2)(An),{agents:n,selectedAgent:o,loadingState:i,filters:l,twins:s,userRole:d,latestLogs:p,isLogLoading:u,hasAgents:m,setFilters:g,setSelectedAgent:y,handleNavigateToCreate:h,handleNavigateToTwin:b,handlePausePlay:v,handleDelete:E,handleLinkTwins:w,handleUnlinkTwin:x,fetchLog:$}=kn(e),[O,C]=(0,a.useState)(void 0),S=f(d),k=e=>{(null==o?void 0:o.id)===e.id?y(void 0):y(e)};return i===gt.READY||m?m||i!==gt.READY?r().createElement("div",{className:t.wrapper},r().createElement("div",{className:t.toolbar},r().createElement("div",{className:t.searchContainer},r().createElement(c.Input,{prefix:r().createElement(c.Icon,{name:"search"}),placeholder:"Search...",value:l.search,onChange:e=>{const t=e.currentTarget.value;g((e=>Mn(Ln({},e),{search:t})))}})),r().createElement("div",{style:{width:180}},r().createElement(c.Select,{options:En,value:l.type,onChange:e=>g((t=>Mn(Ln({},t),{type:e}))),prefix:r().createElement(c.Icon,{name:"filter"})})),r().createElement("div",{style:{flex:1,display:"flex",justifyContent:"flex-end"}},S&&r().createElement(c.Button,{icon:"plus",onClick:h},"New Agent"))),r().createElement("div",{className:t.splitLayout},r().createElement("div",{className:t.leftColumn},r().createElement("div",{className:t.cardsGrid},n.length>0?n.map((e=>r().createElement(Nn,{key:e.id,agent:e,isSelected:(null==o?void 0:o.id)===e.id,onClick:k,onPause:v,onDelete:C,canEdit:S}))):r().createElement("div",{className:t.centerMessage,style:{gridColumn:"1 / -1",marginTop:40}},r().createElement("p",null,'No results match "',l.search,'"')))),r().createElement("div",{className:t.rightColumn},o?r().createElement("div",{className:t.detailsContent},r().createElement(In,{agent:o,twins:s,latestLogs:p,isLoadingLog:u,canEdit:S,onLoadLog:$,onLinkTwins:e=>w(o.id,o.info.namespace,e),onUnlinkTwin:e=>x(o.id,o.info.namespace,e),onNavigateTwin:b,onClose:()=>y(void 0)})):r().createElement("div",{className:t.placeholderContainer},r().createElement("div",{className:t.placeholderContent},r().createElement(c.Icon,{name:"info-circle",size:"xl",style:{marginBottom:"12px",marginTop:"10px"}}),r().createElement("p",null,"Select an agent from the list to view its details, logs and configuration."))))),r().createElement(c.ConfirmModal,{isOpen:!!O,title:"Delete Agent",body:`Are you sure you want to delete ${null==O?void 0:O.name}?`,confirmText:"Delete",onConfirm:()=>{O&&E(O).then((()=>C(void 0)))},onDismiss:()=>C(void 0)})):r().createElement("div",{className:t.centerContent},r().createElement("h3",null,"No agents found"),r().createElement("p",null,"There are no agents configured for this twin yet."),S&&r().createElement(c.LinkButton,{icon:"plus",variant:"primary",onClick:h},"New Agent")):r().createElement("div",{className:t.loadingContainer},r().createElement(c.Spinner,{size:20}))}var Bn=function(e){return e.information="information",e.children="children",e.agents="agents",e.simulations="simulations",e}(Bn||{});function Fn({path:e,id:t,meta:n,section:i}){const l=(0,o.useHistory)(),s=(0,o.useLocation)(),[c,d]=(0,a.useState)(i||"information"),[p,u]=(0,a.useState)({thingId:"",policyId:""}),m=(0,a.useContext)(Ve),g=`${s.pathname.split("/twins")[0]}/${e}`;(0,a.useEffect)((()=>{i&&i!==c?d(i):i||"information"===c||d("information")}),[i]);(0,a.useEffect)((()=>{wt(t).then((e=>u(e))).catch((e=>console.error("Error fetching twin:",e)))}),[t]);return r().createElement(a.Fragment,null,r().createElement(Zt,{thing:p,isType:!1,sections:Object.values(Bn).filter((e=>{if("agents"!==e)return!0;try{var t;return new URL((null===(t=m.agent_endpoint)||void 0===t?void 0:t.trim())||""),!0}catch(e){return!1}})),selected:c,setSelected:e=>{d(e),l.push(`${g}/${t}/${e}`)},funcDelete:Ct,funcDeleteChildren:Qt,enableCopy:!0}),(()=>{switch(c){case"children":return r().createElement(bn,{isType:!1,funcThings:xt,funcDelete:Ct,funcDeleteChildren:Qt,parentId:t,iniCompactMode:!1});case"simulations":return r().createElement(dn,{id:t,meta:n,twinInfo:p});case"agents":var e;return(null===(e=m.agent_endpoint)||void 0===e?void 0:e.trim())?r().createElement(zn,{twinId:t}):r().createElement("div",{style:{padding:20}},"No agent endpoint configured");default:return r().createElement(mn,{thingInfo:p})}})())}function qn(){return r().createElement(bn,{isType:!1,funcThings:xt,funcDelete:Ct,funcDeleteChildren:Qt})}function Gn(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function Un(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){Gn(o,a,r,i,l,"next",e)}function l(e){Gn(o,a,r,i,l,"throw",e)}i(void 0)}))}}const _n=(e,t)=>Un((function*(){return yield te(`${X}/types/${e}`,{method:"PUT",data:t})}))(),Hn=e=>Un((function*(){return yield te(`${X}/types/${e}`,{method:"GET"})}))(),Wn=(e,t=50,n="")=>Un((function*(){let a=`size(${t})`;e&&(a+=`,cursor(${e})`);const r=["eq(attributes/_isType,true)"];if(n){const e=n.replace(/"/g,'\\"'),t=e.toLowerCase(),a=e.toUpperCase(),o=e.charAt(0).toUpperCase()+e.slice(1).toLowerCase(),i=`or(like(thingId,"*${e}*"),like(attributes/name,"*${e}*"),like(attributes/name,"*${t}*"),like(attributes/name,"*${a}*"),like(attributes/name,"*${o}*"))`;r.push(i)}const o=`and(${r.join(",")})`,i=`${Z}/search/things?option=${a}&filter=${o}`,l=yield te(i,{method:"GET",headers:{"Cache-Control":"no-cache",Pragma:"no-cache","X-Cache-Skip":"true"}});return(null==l?void 0:l.items)?{items:l.items,cursor:l.cursor}:Array.isArray(l)?{items:l,cursor:void 0}:{items:[],cursor:void 0}}))(),Jn=()=>Un((function*(){return yield te(`${X}/types/all`,{method:"GET"})}))(),Kn=e=>Un((function*(){return yield te(`${X}/types/${e}`,{method:"DELETE"})}))();function Vn(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function Yn(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){Vn(o,a,r,i,l,"next",e)}function l(e){Vn(o,a,r,i,l,"throw",e)}i(void 0)}))}}const Qn=()=>Yn((function*(){return yield te(`${X}/policies`,{method:"GET"})}))();function Xn(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function Zn(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){Xn(o,a,r,i,l,"next",e)}function l(e){Xn(o,a,r,i,l,"throw",e)}i(void 0)}))}}function ea(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function ta(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){ea(e,t,n[t])}))}return e}function na(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function aa(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){na(e,t,n[t])}))}return e}function ra(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const oa=({attributes:e,setAttributes:t,disabled:n})=>{const o=(0,c.useStyles2)(ia),[i,l]=(0,a.useState)({key:"",value:""});return r().createElement("div",{className:o.container},!n&&r().createElement("div",{className:o.inputRow},r().createElement("div",{className:o.fieldGrow},r().createElement(c.Input,{placeholder:"Key (e.g. location)",value:i.key,onChange:e=>l(ra(aa({},i),{key:e.currentTarget.value}))})),r().createElement("div",{className:o.fieldGrow},r().createElement(c.Input,{placeholder:"Value (e.g. Warehouse 1)",value:String(i.value),onChange:e=>l(ra(aa({},i),{value:e.currentTarget.value}))})),r().createElement(c.Button,{variant:"secondary",onClick:()=>{if(!i.key)return;const n=e.findIndex((e=>e.key===i.key));if(n>=0){const a=[...e];a[n]=i,t(a)}else t([...e,i]);l({key:"",value:""})},icon:"plus"},"Add")),r().createElement("div",{className:o.list},0===e.length&&r().createElement("div",{className:o.empty},"No attributes added."),e.map(((a,i)=>r().createElement("div",{key:`${a.key}-${i}`,className:o.listItem},r().createElement("span",{className:o.keyText},a.key,":"),r().createElement("span",{className:o.valueText},String(a.value)),!n&&r().createElement(c.IconButton,{"aria-labelledby":"",name:"trash-alt",variant:"destructive",size:"sm",onClick:()=>{return n=a.key,void t(e.filter((e=>e.key!==n)));var n}}))))))},ia=e=>({container:l.css`
        display: flex; 
        flex-direction: column; 
        gap: ${e.spacing(2)};
    `,inputRow:l.css`
        display: flex; 
        gap: ${e.spacing(1)}; 
        align-items: flex-start; /* Alineamos arriba por si los inputs tienen distinta altura */
    `,fieldGrow:l.css`
        flex: 1;
    `,list:l.css`
        border: 1px solid ${e.colors.border.weak}; 
        border-radius: ${e.shape.borderRadius()};
        background-color: ${e.colors.background.secondary};
    `,listItem:l.css`
        display: flex; 
        justify-content: space-between; 
        align-items: center; /* Puedes cambiar a 'flex-start' si quieres el botón arriba en textos muy largos */
        padding: ${e.spacing(1)} ${e.spacing(2)};
        border-bottom: 1px solid ${e.colors.border.weak};
        gap: ${e.spacing(2)}; 
        
        &:last-child { 
            border-bottom: none; 
        }
        &:hover { 
            background: ${e.colors.action.hover}; 
        }
    `,textWrapper:l.css`
        display: flex;
        flex-direction: column; /* En pantallas muy pequeñas, key y value uno debajo del otro */
        flex: 1;
        gap: ${e.spacing(.5)};
        
        @media (min-width: 600px) {
            flex-direction: row;
            align-items: baseline;
        }
    `,keyText:l.css`
        font-weight: 600; 
        margin-right: ${e.spacing(1)};
        white-space: nowrap; /* Evita que la Key se rompa si es corta */
        flex-shrink: 0;      /* Asegura que la Key no se aplaste */
        color: ${e.colors.text.primary};
    `,valueText:l.css`
        flex: 1; 
        color: ${e.colors.text.secondary};
        
        /* PROPIEDADES CLAVE PARA EL WRAPPING */
        white-space: pre-wrap;      /* Respeta saltos de línea si los hay */
        overflow-wrap: anywhere;    /* Rompe palabras largas en cualquier punto si es necesario */
        word-break: break-word;     /* Compatibilidad adicional */
        min-width: 0;               /* Truco Flexbox: permite que el texto haga wrap dentro de un flex child */
    `,empty:l.css`
        padding: ${e.spacing(2)}; 
        color: ${e.colors.text.disabled}; 
        font-style: italic; 
        text-align: center;
    `}),la=({features:e,setFeatures:t,disabled:n})=>{const o=(0,c.useStyles2)(sa),[i,l]=(0,a.useState)("");return r().createElement("div",{className:o.container},!n&&r().createElement("div",{className:o.inputRow},r().createElement("div",{className:o.fieldGrow},r().createElement(c.Input,{placeholder:"Feature Name (e.g. spotlight)",value:i,onChange:e=>l(e.currentTarget.value)})),r().createElement(c.Button,{variant:"secondary",onClick:()=>{i&&(e.some((e=>e.name===i))||(t([...e,{name:i,properties:{value:null}}]),l("")))},icon:"plus"},"Add")),r().createElement("div",{className:o.list},0===e.length&&r().createElement("div",{className:o.empty},"No features added."),e.map(((a,i)=>r().createElement("div",{key:`${a.name}-${i}`,className:o.listItem},r().createElement("span",{className:o.keyText},a.name),!n&&r().createElement(c.IconButton,{"aria-labelledby":"",name:"trash-alt",variant:"destructive",size:"sm",onClick:()=>{return n=a.name,void t(e.filter((e=>e.name!==n)));var n}}))))))},sa=e=>({container:l.css`
        display: flex; 
        flex-direction: column; 
        gap: ${e.spacing(2)};
    `,inputRow:l.css`
        display: flex; 
        gap: ${e.spacing(1)}; 
        align-items: center;
    `,fieldGrow:l.css`
        flex: 1;
    `,list:l.css`
        border: 1px solid ${e.colors.border.weak}; 
        border-radius: ${e.shape.borderRadius()};
        background-color: ${e.colors.background.secondary};
    `,listItem:l.css`
        display: flex; 
        justify-content: space-between; 
        align-items: center; 
        padding: ${e.spacing(1)} ${e.spacing(2)};
        border-bottom: 1px solid ${e.colors.border.weak};
        gap: ${e.spacing(2)}; /* Espacio entre el nombre y el botón */

        &:last-child { 
            border-bottom: none; 
        }
        &:hover {
            background: ${e.colors.action.hover};
        }
    `,keyText:l.css`
        font-weight: 500;
        flex: 1; /* Ocupa todo el espacio disponible empujando el botón a la derecha */
        overflow-wrap: anywhere;  
        word-break: break-word;
        white-space: pre-wrap;
        min-width: 0;           
        color: ${e.colors.text.primary};
    `,empty:l.css`
        padding: ${e.spacing(2)}; 
        color: ${e.colors.text.disabled}; 
        font-style: italic; 
        text-align: center;
    `});function ca(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function da(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){ca(e,t,n[t])}))}return e}function pa(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const ua=({thingToEdit:e,isType:t,funcFromType:n,funcFromZero:l,parentId:d})=>{const p=(0,c.useStyles2)(ma),u="thing-form-id",{url:m}=(0,o.useRouteMatch)(),f=e?"edit":"new",y=m.split(`/${f}`)[0]+(d?t?"/hierarchy":"/children":""),[h,b]=(0,a.useState)(!1),{thingIdField:v,setThingIdField:E,policyId:w,setPolicyId:x,basicInfo:$,setBasicInfo:O,attributes:C,setAttributes:S,features:k,setFeatures:T,policies:P,types:N,creationMode:j,setCreationMode:I,selectedType:D,setSelectedType:A,customizeType:R,setCustomizeType:L,numChildren:M,setNumChildren:z,isLoading:B,saveThing:F,goBackToList:q,allowFromType:G,disableAdvancedFields:U,previewJson:_}=(({thingToEdit:e,isType:t,funcFromType:n,funcFromZero:r,resourceRoot:l})=>{const c=(0,o.useHistory)(),d=(0,i.getAppEvents)(),[p,u]=(0,a.useState)(!1),[m,f]=(0,a.useState)([]),[y,h]=(0,a.useState)([]),[b,v]=(0,a.useState)(Ze),[E,w]=(0,a.useState)(),[x,$]=(0,a.useState)(!1),[O,C]=(0,a.useState)({id:"",namespace:""}),[S,k]=(0,a.useState)(""),[T,P]=(0,a.useState)(1),[N,j]=(0,a.useState)({name:"",description:"",image:""}),[I,D]=(0,a.useState)([]),[A,R]=(0,a.useState)([]),[L,M]=(0,a.useState)({}),z=!t&&!e,B=p||b===Xe&&!x,F=(e={})=>{const t=ta({},e),n={name:t.name||"",description:t.description||"",image:t.image||""},a={};return ot.forEach((e=>{t.hasOwnProperty(e)&&(a[e]=t[e],delete t[e])})),lt.forEach((e=>delete t[e])),it.forEach((e=>delete t[e])),{basic:n,hidden:a,custom:(r=t,Object.keys(r).map((e=>({key:e,value:r[e]}))))};var r};(0,a.useEffect)((()=>{Zn((function*(){if(yield g()){Qn().then((e=>f(e.map((e=>({label:e,value:e})))))).catch((e=>console.error("Error loading initial data",e)));try{if(z){const e=yield Jn();h(e.map((e=>({label:e.thingId,value:e}))))}e?q(e):v(z?Xe:Ze)}catch(e){console.error("Error loading initial data",e)}}else c.replace(l)}))()}),[z,e,c,l]);const q=e=>{const{id:t,namespace:n}=(e=>{const t=e.split(":");return 0===t.length?{id:"",namespace:""}:1===t.length?{id:"",namespace:t[0]}:{namespace:t[0],id:t.slice(1).join(":")}})(e.thingId);C({id:t,namespace:n}),k(e.policyId);const{basic:a,hidden:r,custom:o}=F(e.attributes);j(a),M(r),D(o),R(Ye(e.features))};(0,a.useEffect)((()=>{if(b===Xe&&(null==E?void 0:E.value)){const e=E.value;k(null==e?void 0:e.policyId),R(Ye(e.features));const{basic:t,hidden:n,custom:a}=F(e.attributes);j(t),M(n);const r=[...a];D(r)}}),[E,b]);const G=()=>{const e=ta({},N,L,I.reduce(((e,t)=>(t.key&&(e[t.key]=t.value),e)),{}));let t={thingId:`${O.namespace}:${O.id}`,policyId:S,attributes:e,features:A.reduce(((e,t)=>(t.name&&(e[t.name]={properties:t.properties||{}}),e)),{})};return t.policyId||delete t.policyId,t},U=()=>{i.locationService.push(l)};return{thingIdField:O,setThingIdField:C,policyId:S,setPolicyId:k,basicInfo:N,setBasicInfo:j,attributes:I,setAttributes:D,features:A,setFeatures:R,numChildren:T,setNumChildren:P,policies:m,types:y,creationMode:b,setCreationMode:v,selectedType:E,setSelectedType:w,customizeType:x,setCustomizeType:$,allowFromType:z,disableAdvancedFields:B,isLoading:p,saveThing:()=>Zn((function*(){if(!O.id||!O.namespace)return void d.publish({type:s.AppEvents.alertWarning.name,payload:["Validation Error","Namespace and ID are required."]});u(!0);const e=G(),a={policyId:null==e?void 0:e.policyId,attributes:e.attributes,features:e.features};try{let o;if(b===Xe&&(null==E?void 0:E.value)&&z){const t=E.value.thingId;o=x?n(e.thingId,t,a):n(e.thingId,t)}else{const n=t?Math.floor(Number(T)):void 0;o=r(e.thingId,a,n)}yield o,yield new Promise((e=>setTimeout(e,3e3))),d.publish({type:s.AppEvents.alertSuccess.name,payload:["Success",(t?"Type":"Twin")+" saved successfully."]}),U()}catch(e){console.error("API Error details:",e);let t="Check console for details.";e.data&&e.data.message?t=e.data.message:e.message&&(t=e.message),d.publish({type:s.AppEvents.alertError.name,payload:["Bad Request / Error",t]})}finally{u(!1)}}))(),goBackToList:U,previewJson:JSON.stringify(G(),null,4)}})({thingToEdit:e,isType:t,funcFromType:n,funcFromZero:l,resourceRoot:y}),H=t?"Type":"Twin",W=e?`Edit ${H}: ${e.thingId}`:`Create New ${H}`,J=B?e?"Updating...":"Creating...":e?"Save Changes":"Create",K=B?"spinner":void 0;return r().createElement("div",{className:p.centeredWrapper},r().createElement("div",{className:p.formPanel},r().createElement("div",{className:p.header},r().createElement("div",null,r().createElement("h2",null,W),d&&r().createElement("div",{style:{opacity:.7,fontSize:"0.9em"}},"Parent: ",d)),r().createElement(c.Button,{variant:"secondary",fill:"outline",icon:"arrow-left",onClick:q},"Back")),r().createElement(c.Form,{id:u,onSubmit:F,className:p.formContainer},(({register:n,errors:a})=>r().createElement(r().Fragment,null,r().createElement(c.FieldSet,{label:"Identification"},r().createElement("div",{className:p.flexRow},r().createElement(c.Field,{label:"Namespace",required:!e,className:p.flexField,description:`Context for the ${H}.`},r().createElement(c.Input,{value:v.namespace,onChange:e=>E(pa(da({},v),{namespace:e.currentTarget.value})),disabled:!!e,placeholder:"e.g. org.eclipse.ditto"})),r().createElement(c.Field,{label:"ID",required:!e,className:p.flexField,description:"Unique identifier (without namespace)."},r().createElement(c.Input,{value:v.id,onChange:e=>E(pa(da({},v),{id:e.currentTarget.value})),disabled:!!e,placeholder:"my-thing-01"}))),t&&!e&&void 0!==d&&r().createElement(c.Field,{label:"Number of children",description:"Instances to create based on this type."},r().createElement(c.Input,{type:"number",value:M,onChange:e=>z(Number(e.currentTarget.value))}))),G&&r().createElement(c.FieldSet,{label:"Creation strategy",className:"mt-3"},r().createElement("div",{className:"mb-3"},r().createElement(c.RadioButtonGroup,{options:at,fullWidth:!0,value:j,onChange:e=>I(e)})),j===Xe&&r().createElement("div",{className:p.subSection},r().createElement(c.Field,{label:"Select Base Type",required:!0},r().createElement(c.Select,{options:N,value:D,onChange:A,prefix:r().createElement(c.Icon,{name:"layer-group"})})),r().createElement(c.Field,{label:"Customize properties",description:"Override properties from the selected type"},r().createElement(c.Switch,{value:R,onChange:e=>L(!R)})))),r().createElement("div",{className:"mt-1"},r().createElement("h4",null,"General details"),r().createElement("p",{className:p.sectionDesc},"General Details include essential information used to identify and describe the twin."),r().createElement(c.Field,{label:"Policy ID"},r().createElement(c.Select,{options:P,value:w,onChange:e=>x(e.value),disabled:U})),r().createElement(c.Field,{label:"Name"},r().createElement(c.Input,{value:$.name,onChange:e=>O(pa(da({},$),{name:e.currentTarget.value})),disabled:U})),r().createElement(c.Field,{label:"Description"},r().createElement(c.Input,{value:$.description,onChange:e=>O(pa(da({},$),{description:e.currentTarget.value})),disabled:U})),r().createElement(c.Field,{label:"Image URL"},r().createElement(c.Input,{value:$.image,onChange:e=>O(pa(da({},$),{image:e.currentTarget.value})),disabled:U}))),r().createElement("div",{className:"mt-4"},r().createElement("h4",null,"Attributes"),r().createElement("p",{className:p.sectionDesc},"Attributes describe static characteristics of a twin and help identify it. Their values change rarely."),r().createElement("div",{className:p.editorSection},r().createElement(oa,{attributes:C,setAttributes:S,disabled:U}),r().createElement("div",{style:{height:"20px"}})),r().createElement("h4",null,"Features"),r().createElement("p",{className:p.sectionDesc},"Features represent dynamic aspects of a twin, grouping data and functionality that change or operate over time."),r().createElement("div",{className:p.editorSection},r().createElement(la,{features:k,setFeatures:T,disabled:U}))),r().createElement("div",{className:"mt-4"},r().createElement(c.Button,{variant:"secondary",size:"sm",fill:"text",icon:h?"angle-up":"angle-down",onClick:()=>b(!h)},h?"Hide JSON Preview":"Show JSON Preview"),h&&r().createElement(c.TextArea,{className:p.textArea,value:_,readOnly:!0}))))),r().createElement("div",{className:p.buttonGroup},r().createElement(c.Button,{variant:"primary",type:"submit",form:u,disabled:B,icon:K},J))))},ma=e=>({centeredWrapper:l.css`
        display: flex;
        justify-content: center;
        width: 100%;
        padding-bottom: ${e.spacing(4)};
    `,formPanel:l.css`
        background-color: ${e.colors.background.primary};
        border: 1px solid ${e.colors.border.weak};
        border-radius: ${e.shape.borderRadius()};
        padding: ${e.spacing(4)};
        box-shadow: ${e.shadows.z1};
        width: 100%;
        max-width: 900px;
        display: flex;
        flex-direction: column;
    `,header:l.css`
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: ${e.spacing(3)};
        border-bottom: 1px solid ${e.colors.border.weak};
        padding-bottom: ${e.spacing(2)};
        
        h2 {
            margin: 0;
            font-size: ${e.typography.h3.fontSize};
        }
    `,formContainer:l.css`
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    `,flexRow:l.css`
        display: flex;
        gap: ${e.spacing(2)};
        width: 100%;
    `,flexField:l.css`
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    `,editorSection:l.css`
        margin-top: ${e.spacing(2)};
        display: flex;
        flex-direction: column;
    `,subSection:l.css`
        padding: ${e.spacing(2)};
        background: ${e.colors.background.secondary};
        border-radius: ${e.shape.borderRadius()};
        margin-bottom: ${e.spacing(2)};
    `,sectionDesc:l.css`
        color: ${e.colors.text.secondary};
        font-size: ${e.typography.bodySmall.fontSize};
        margin-bottom: ${e.spacing(2)};
    `,textArea:l.css`
        font-family: ${e.typography.fontFamilyMonospace};
        min-height: 400px;
        resize: vertical;
        margin-top: ${e.spacing(2)};
        font-size: 12px;
    `,buttonGroup:l.css`
        display: flex;
        justify-content: flex-end;
        gap: ${e.spacing(2)};
        margin-top: ${e.spacing(4)};
        padding-top: ${e.spacing(2)};
        border-top: 1px solid ${e.colors.border.weak};
    `}),ga=({meta:e,twinId:t,parentId:n})=>{const[o,i]=(0,a.useState)(),[l,s]=(0,a.useState)(!!t);(0,a.useEffect)((()=>{t&&(s(!0),wt(t).then((e=>{i(e)})).catch((e=>{console.error("Error fetching twin data",e)})).finally((()=>{s(!1)})))}),[t]);const d=(0,a.useCallback)(((e,a)=>t?Et(e,a):n?Yt(n,e,a):Et(e,a)),[t,n]),p=(0,a.useCallback)(((e,a,r)=>{const o=((e,t,n)=>Un((function*(){const a={method:"POST"};return n&&(a.data=n),yield te(`${X}/types/${t}/create/${e}`,a)}))())(e,a,r);return!t&&n?o.then((()=>Yt(n,e))):o}),[n,t]);return l?r().createElement("div",{style:{display:"flex",justifyItems:"center",justifyContent:"center",alignContent:"center"}},r().createElement(c.Spinner,{size:20})):r().createElement(ua,{meta:e,thingToEdit:o,parentId:n,isType:!1,funcFromZero:d,funcFromType:p})};function fa(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function ya(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function ha(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){ya(e,t,n[t])}))}return e}function ba(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const va=e=>{const t=(0,i.getAppEvents)(),[n,r]=(0,a.useState)(!1),l=(0,o.useHistory)(),{url:c}=(0,o.useRouteMatch)();return{isLoading:n,handleDuplicateTwin:n=>{return(a=function*(){r(!0);try{yield St(e,`${n.namespace}:${n.id}`),t.publish({type:s.AppEvents.alertSuccess.name,payload:["The twin has been duplicated successfully. You can access it from the main twins tab."]})}catch(e){t.publish({type:s.AppEvents.alertError.name,payload:["The twin could not be duplicated. Check the fields entered and the API connection."]})}finally{r(!1)}},function(){var e=this,t=arguments;return new Promise((function(n,r){var o=a.apply(e,t);function i(e){fa(o,n,r,i,l,"next",e)}function l(e){fa(o,n,r,i,l,"throw",e)}i(void 0)}))})();var a},goBackToList:()=>{const t=c.split("/twins")[0]+"/twins/"+e;l.push(t)}}};function Ea({id:e}){const t=(0,c.useStyles2)(wa),{isLoading:n,handleDuplicateTwin:o,goBackToList:i}=va(e);return(0,a.useEffect)((()=>{g().then((e=>{e||(ke.warn("[Auth] User lacks permissions. Redirecting."),i())}))}),[]),r().createElement("div",{className:t.centeredWrapper},r().createElement("div",{className:t.formPanel},r().createElement("div",{className:t.header},r().createElement("div",null,r().createElement("h2",null,"Duplicate Twin"),r().createElement("p",{className:t.subHeader},"Enter the id and namespace you want the duplicate twin to have. Note that all its children will also be copied.")),r().createElement(c.Button,{variant:"secondary",fill:"outline",icon:"arrow-left",onClick:i},"Back")),r().createElement(c.Form,{onSubmit:o,className:t.formContainer,maxWidth:"none"},(({register:e,errors:a})=>{var o,i;return r().createElement(r().Fragment,null,r().createElement(c.Field,{label:"Namespace",required:!0,disabled:n,invalid:!!a.namespace,error:null===(o=a.namespace)||void 0===o?void 0:o.message},r().createElement(c.Input,ba(ha({},e("namespace",{required:"Namespace is required"})),{placeholder:"e.g. production",disabled:n}))),r().createElement(c.Field,{label:"Id",required:!0,disabled:n,invalid:!!a.id,error:null===(i=a.id)||void 0===i?void 0:i.message},r().createElement(c.Input,ba(ha({},e("id",{required:"ID is required"})),{placeholder:"e.g. my-new-twin-01",disabled:n}))),r().createElement("div",{className:t.buttonGroup},n&&r().createElement(c.Spinner,{size:20,style:{marginRight:"10px"}}),r().createElement(c.Button,{type:"submit",variant:"primary",disabled:n},n?"Duplicating...":"Duplicate")))}))))}const wa=e=>({centeredWrapper:l.css`
        display: flex;
        justify-content: center;
        width: 100%;
        padding-bottom: ${e.spacing(4)};
    `,formPanel:l.css`
        background-color: ${e.colors.background.primary};
        border: 1px solid ${e.colors.border.weak};
        border-radius: ${e.shape.borderRadius()};
        padding: ${e.spacing(4)};
        box-shadow: ${e.shadows.z1};
        width: 100%;
        max-width: 600px; /* Un poco más estrecho que AgentForm ya que tiene menos campos */
        display: flex;
        flex-direction: column;
    `,header:l.css`
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: ${e.spacing(3)};
        border-bottom: 1px solid ${e.colors.border.weak};
        padding-bottom: ${e.spacing(2)};
        
        h2 {
            margin: 0;
            font-size: ${e.typography.h3.fontSize};
        }
    `,subHeader:l.css`
        color: ${e.colors.text.secondary};
        margin-top: ${e.spacing(1)};
        font-size: ${e.typography.bodySmall.fontSize};
    `,formContainer:l.css`
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    `,buttonGroup:l.css`
        display: flex;
        justify-content: flex-end;
        align-items: center;
        gap: ${e.spacing(2)};
        margin-top: ${e.spacing(4)};
        padding-top: ${e.spacing(2)};
        border-top: 1px solid ${e.colors.border.weak};
    `});var xa=function(e){return e.List="list",e.Check="check",e.Create="create",e.Edit="edit",e.Copy="copy",e}({}),$a=function(e){return e.Twin="twin",e.Simulation="simulation",e}({});const Oa=({meta:e,pageMode:t="list",elementType:n="twin"})=>{const l=(0,c.useStyles2)(Ca),d="twins",{id:p,section:u,simulationId:m}=(0,o.useParams)(),g=(0,a.useMemo)((()=>Qe(e)),[e]);return r().createElement(i.PluginPage,{layout:s.PageLayoutType.Canvas},r().createElement("div",{className:l.container},r().createElement(Ve.Provider,{value:g},"check"===t?p?r().createElement(Fn,{path:d,id:p,meta:e,section:u}):r().createElement(c.Alert,{title:"Error"},"Missing Twin ID for check mode."):"create"===t?"simulation"===n?p?r().createElement(Jt,{path:d,id:p,meta:e}):r().createElement(c.Alert,{title:"Error"},"Twin ID required to create simulation."):r().createElement(ga,{meta:e,parentId:p}):"edit"===t?p?"simulation"===n?r().createElement(Jt,{path:d,id:p,meta:e,simulationId:m}):r().createElement(ga,{meta:e,twinId:p}):r().createElement(qn,null):"copy"===t?p?r().createElement(Ea,{id:p}):r().createElement(c.Alert,{title:"Error"},"Missing Twin ID for copy mode."):r().createElement(qn,null))))},Ca=e=>({container:l.css`
    display: flex;
    flex-direction: column;
    gap: ${e.spacing(2)};
    width: 100%;
    min-height: 100%;
  `});function Sa(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function ka(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){Sa(o,a,r,i,l,"next",e)}function l(e){Sa(o,a,r,i,l,"throw",e)}i(void 0)}))}}const Ta=()=>{const e=(0,i.getAppEvents)(),[t,n]=(0,a.useState)([]),[r,o]=(0,a.useState)(),[l,c]=(0,a.useState)(void 0),[d,p]=(0,a.useState)(""),[u,m]=(0,a.useState)(!1),[g,f]=(0,a.useState)(!1),[y,h]=(0,a.useState)(!1),b=(0,a.useCallback)((()=>ka((function*(){m(!0);try{const e=yield Qn();n(e.map((e=>({label:e,value:e}))))}catch(t){e.publish({type:s.AppEvents.alertError.name,payload:["Error fetching policies list"]})}finally{m(!1)}}))()),[e]);(0,a.useEffect)((()=>{var e;(null==r?void 0:r.value)?(m(!0),(e=r.value,Yn((function*(){return yield te(`${Z}/policies/${e}`,{method:"GET"})}))()).then((e=>c(e))).catch((()=>c(void 0))).finally((()=>m(!1)))):c(void 0)}),[r]),(0,a.useEffect)((()=>{b()}),[b]);return{policies:t,selectedId:r,setSelectedId:o,selectedPolicyContent:l,newPolicyJson:d,setNewPolicyJson:p,isLoading:u,isProcessing:g,showDeleteModal:y,setShowDeleteModal:h,onDeleteConfirm:()=>ka((function*(){if(null==r?void 0:r.value){f(!0);try{yield(t=r.value,Yn((function*(){return yield te(`${Z}/policies/${t}`,{method:"DELETE"})}))()),e.publish({type:s.AppEvents.alertSuccess.name,payload:["Policy deleted successfully"]}),o(void 0),b()}catch(t){e.publish({type:s.AppEvents.alertError.name,payload:["Error deleting policy"]})}finally{f(!1),h(!1)}var t}}))(),onSavePolicy:()=>ka((function*(){if(!d.trim())return;let t;try{t=JSON.parse(d)}catch(t){return void e.publish({type:s.AppEvents.alertWarning.name,payload:["Invalid JSON format. Please check your syntax."]})}f(!0);try{yield(n=t,Yn((function*(){return yield te(`${Z}/policies/${n.policyId}`,{method:"PUT",data:{entries:n.entries}})}))()),e.publish({type:s.AppEvents.alertSuccess.name,payload:["Policy saved successfully"]}),p(""),b()}catch(t){let n=t.message;try{n=JSON.parse(t.message).message}catch(e){}e.publish({type:s.AppEvents.alertError.name,payload:["Error saving policy: "+n]})}finally{f(!1)}var n}))(),onEditPolicy:()=>{l&&(p(JSON.stringify(l,void 0,4)),e.publish({type:s.AppEvents.alertInfo.name,payload:["Policy content copied to editor"]}))}}},Pa=e=>({container:l.css`
            padding: ${e.spacing(2)};
            height: 100%;
            display: flex;
            flex-direction: column;
        `,mainLayout:l.css`
            display: flex;
            flex-direction: row;
            gap: ${e.spacing(3)};
            height: 100%;
            /* Responsive: Stack on small screens */
            @media (max-width: 1000px) {
                flex-direction: column;
            }
        `,panel:l.css`
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: ${e.spacing(2)};
            padding: ${e.spacing(2)};
            background: ${e.colors.background.secondary};
            border: 1px solid ${e.colors.border.weak};
            border-radius: ${e.shape.borderRadius()};
            height: 100%;
            min-height: 700px;
        `,panelHeader:l.css`
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid ${e.colors.border.weak};
            padding-bottom: ${e.spacing(1.5)};
            margin-bottom: ${e.spacing(1)};
        `,panelTitle:l.css`
            font-size: ${e.typography.h4.fontSize};
            font-weight: ${e.typography.fontWeightBold};
            margin: 0;
        `,toolbar:l.css`
            display: flex;
            gap: ${e.spacing(2)};
            align-items: center;
        `,editorContainer:l.css`
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        `,codeTextArea:l.css`
            font-family: ${e.typography.fontFamilyMonospace} !important;
            font-size: 12px;
            flex-grow: 1;
            resize: none; 
            min-height: 300px;
        `,actionsRow:l.css`
            display: flex;
            justify-content: flex-end;
            gap: ${e.spacing(1)};
            margin-top: auto;
        `,disclaimerBox:l.css`
            margin-bottom: ${e.spacing(0)};
        `,noPermission:l.css`
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: ${e.colors.text.secondary};
        `}),Na=({path:e})=>{const t=(0,c.useStyles2)(Pa),[n,o]=(0,a.useState)(u.VIEWER),{policies:i,selectedId:l,setSelectedId:s,selectedPolicyContent:d,newPolicyJson:p,setNewPolicyJson:g,isLoading:f,isProcessing:h,showDeleteModal:b,setShowDeleteModal:v,onDeleteConfirm:E,onSavePolicy:w,onEditPolicy:x}=Ta();return(0,a.useEffect)((()=>{m().then((e=>o(e)))}),[]),y(n,u.EDITOR)?r().createElement("div",{className:t.container},r().createElement("div",{className:t.mainLayout},r().createElement("div",{className:t.panel},r().createElement("div",{className:t.panelHeader},r().createElement("span",{className:t.panelTitle},"Policies"),f&&r().createElement(c.Spinner,{size:14})),r().createElement("div",{className:t.toolbar},r().createElement("div",{style:{flexGrow:1}},r().createElement(c.Select,{options:i,value:l,onChange:e=>s(e),prefix:r().createElement(c.Icon,{name:"search"}),placeholder:"Select policy...",isClearable:!0})),r().createElement(c.Button,{variant:"secondary",icon:"pen",disabled:!l||h,onClick:x,tooltip:"Copy JSON to create/update panel"},"Edit"),r().createElement(c.Button,{variant:"destructive",icon:"trash-alt",disabled:!l||h,onClick:()=>v(!0)},"Delete")),r().createElement("div",{className:t.editorContainer},r().createElement(c.TextArea,{className:t.codeTextArea,value:d?JSON.stringify(d,void 0,4):"",readOnly:!0,placeholder:"// Select a policy to view its content"}))),r().createElement("div",{className:t.panel},r().createElement("div",{className:t.panelHeader},r().createElement("span",{className:t.panelTitle},"Create or Update Policy"),r().createElement(c.Icon,{name:"plus-circle"})),r().createElement("div",{className:t.disclaimerBox},r().createElement(c.Alert,{title:"Important Configuration",severity:"info",className:t.disclaimerBox},"Please ensure you include the ",r().createElement("b",null,"default user")," (configured in Plugin Settings) in the ",r().createElement("code",null,"entries")," list. Otherwise, you won't be able to query this policy or its twins.")),r().createElement("div",{className:t.editorContainer},r().createElement(c.TextArea,{className:t.codeTextArea,value:p,onChange:e=>g(e.currentTarget.value),placeholder:'{\n  "policyId": "example:my-policy",\n  "entries": []\n}'})),r().createElement("div",{className:t.actionsRow},r().createElement(c.Button,{variant:"primary",icon:h?"spinner":"save",onClick:w,disabled:h||!p},h?"Saving...":"Save Policy")))),r().createElement(c.ConfirmModal,{isOpen:b,title:"Delete Policy",body:`Are you sure you want to delete "${null==l?void 0:l.value}"? This action cannot be undone.`,confirmText:"Delete",icon:"trash-alt",onConfirm:E,onDismiss:()=>v(!1)})):r().createElement("div",{className:t.noPermission},r().createElement(c.Icon,{name:"lock",size:"xxl",style:{marginBottom:"10px"}}),r().createElement("h3",null,"Access Denied"),r().createElement("p",null,"You need editor privileges to manage policies."))};var ja=function(e){return e.List="list",e}({});const Ia=({pageMode:e="list"})=>{const t=(0,c.useStyles2)(Da);return r().createElement(i.PluginPage,{layout:s.PageLayoutType.Canvas},r().createElement("div",{className:t.container},r().createElement(Na,{path:"policies"})))},Da=e=>({container:l.css`
    display: flex;
    flex-direction: column;
    gap: ${e.spacing(2)};
    width: 100%;
  `});function Aa({path:e,meta:t}){return r().createElement(bn,{isType:!0,funcThings:Wn,funcDelete:Kn})}function Ra(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function La(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){Ra(o,a,r,i,l,"next",e)}function l(e){Ra(o,a,r,i,l,"throw",e)}i(void 0)}))}}const Ma=(e,t,n,a)=>La((function*(){const r={method:"PUT"};return a&&(r.data=a),yield te(`${X}/types/${e}/children/${t}/${n}`,r)}))(),za=(e,t)=>La((function*(){return yield te(`${X}/types/${e}/children/${t}/unlink`,{method:"PATCH"})}))();function Ba(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function Fa(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){Ba(e,t,n[t])}))}return e}function qa(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}function Ga({id:e,labels:t,funcGet:n,funcUpdate:l,funcUnlink:d,funcGetOptions:p,resourceRoot:u,onCreate:m}){const g=(0,o.useHistory)(),f=(0,c.useTheme2)(),y=(0,i.getAppEvents)(),[h,b]=(0,a.useState)([]),[v,E]=(0,a.useState)([]),[w,x]=(0,a.useState)(),[$,O]=(0,a.useState)(gt.HIDE),[C,S]=(0,a.useState)(),[k,T]=(0,a.useState)([]),[P,N]=(0,a.useState)({id:"",num:1}),j=()=>{n().then((e=>{b(e)})).catch((()=>{y.publish({type:s.AppEvents.alertError.name,payload:["Error getting things"]})})).finally((()=>O(gt.READY)))},I=t=>{O(gt.LOADING),l(t.id,Number(t.num)).then((()=>{setTimeout(j,1e3),y.publish({type:s.AppEvents.alertSuccess.name,payload:[`${e} has been edited correctly`]})})).catch((()=>{j(),y.publish({type:s.AppEvents.alertError.name,payload:[`${e} has not been edited correctly, please check the data you have entered`]})}))};(0,a.useEffect)((()=>{j()}),[]),(0,a.useEffect)((()=>{(()=>{const e=void 0!==h?h.sort(((e,t)=>e.id.localeCompare(t.id))):h;E(null==w?e:e.filter((e=>void 0===w||e.id.includes(w))))})(),p().then((t=>T(t.filter((t=>t!==e&&!h.some((e=>e.id===t)))).map((e=>({label:e,value:e})))))).catch((()=>{}))}),[h,w]),(0,a.useEffect)((()=>{N(void 0===C?{id:"",num:1}:qa(Fa({},P),{id:C&&C.value?C.value:""}))}),[C]);const D=v.map((e=>{const n=e.id.replace(":","_");return r().createElement(c.Form,{id:"form_"+n,onSubmit:I,maxWidth:"none",style:{marginTop:"0px",paddingTop:"0px"},key:e.id},(({register:a})=>r().createElement("div",{className:"row mt-2"},r().createElement("div",{className:"col-12 col-xl-5 mt-1"},r().createElement("div",{style:{display:"flex",alignContent:"center",width:"100%"}},r().createElement(c.InlineLabel,{style:{width:"80px",backgroundColor:f.colors.secondary.main}},t.id),r().createElement(c.Input,qa(Fa({},a("id")),{id:"input_id_"+n,value:e.id,readOnly:!0})))),r().createElement("div",{className:"col-12 col-xl-3 mt-1"},r().createElement("div",{style:{display:"flex",alignContent:"center",width:"100%"}},r().createElement(c.InlineLabel,{style:{width:"80px",backgroundColor:f.colors.secondary.main,overflow:"hidden",lineHeight:"1em"}},t.number),r().createElement(c.Input,qa(Fa({},a("num")),{id:"input_num_"+n,type:"text",value:e.num,onChange:t=>((e,t)=>{let n=JSON.parse(JSON.stringify(h));const a=n.findIndex((e=>e.id===t));n[a]={id:t,num:e.currentTarget.value},b(n)})(t,e.id),disabled:$===gt.LOADING})))),r().createElement("div",{className:"col-12 col-xl-4 mt-1",style:{display:"flex",justifyContent:"flex-end"}},r().createElement(c.Button,{type:"submit",variant:"secondary",style:{marginRight:"5px",width:"100%",justifyContent:"center"},disabled:$===gt.LOADING},"Update"),r().createElement(c.Button,{type:"button",variant:"destructive",style:{marginRight:"5px"},onClick:()=>{return t=e.id,O(gt.LOADING),void d(t).then((()=>{setTimeout(j,1500),y.publish({type:s.AppEvents.alertSuccess.name,payload:[`${t} has been unlinked correctly`]})})).catch((()=>{j(),y.publish({type:s.AppEvents.alertError.name,payload:[`${t} has not been unlinked correctly`]})}));var t},disabled:$===gt.LOADING},"Unlink"),r().createElement(c.Button,{type:"button",variant:"secondary",icon:"external-link-alt",onClick:()=>{return t=e.id,void g.push(`${u}/${t}`);var t},disabled:$===gt.LOADING,tooltip:"Go to details"})))))})),A=r().createElement("div",{className:"row mt-3"},r().createElement("div",{className:"col-12 col-xl-5 mt-1"},r().createElement("div",{style:{display:"flex",alignContent:"center",width:"100%"}},r().createElement(c.InlineLabel,{style:{width:"80px",backgroundColor:f.colors.secondary.main}},t.id),r().createElement(c.Select,{options:k,value:C,onChange:e=>S(e),disabled:$===gt.LOADING}))),r().createElement("div",{className:"col-12 col-xl-3 mt-1"},r().createElement("div",{style:{display:"flex",alignContent:"center",width:"100%"}},r().createElement(c.InlineLabel,{style:{width:"80px",backgroundColor:f.colors.secondary.main,overflow:"hidden",lineHeight:"1em"}},t.number),r().createElement(c.Input,{type:"number",value:P.num,onChange:e=>N(qa(Fa({},P),{num:Number(e.currentTarget.value)})),disabled:$===gt.LOADING}))),r().createElement("div",{className:"col-12 col-xl-4 mt-1",style:{display:"flex",justifyContent:"flex-end"}},r().createElement(c.Button,{type:"button",fullWidth:!0,onClick:()=>{I(P),S({value:"",label:""}),N({id:"",num:1})},disabled:$===gt.LOADING||void 0===C||""===(void 0!==C.value&&C.value.trim())},"Add ",t.buttonsText))),R=h.length<1?r().createElement("h5",{style:{textAlign:"center",marginTop:"20px"}},"There are no items"):r().createElement("div",null);return r().createElement(a.Fragment,null,r().createElement("div",{className:"searchAndButton"},r().createElement("div",{style:{width:"100%",marginRight:"5px"}},r().createElement(c.Input,{value:w,prefix:r().createElement(c.Icon,{name:"search"}),onChange:e=>{x(e.target.value)},placeholder:"Search"})),m&&r().createElement(c.Button,{icon:"plus",variant:"primary",onClick:m},"New Type")),A,r().createElement("div",{className:"row"},v.length>0?D:R))}function Ua(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function _a(e){return function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){Ua(o,a,r,i,l,"next",e)}function l(e){Ua(o,a,r,i,l,"throw",e)}i(void 0)}))}}function Ha({id:e}){const t=(0,c.useTheme2)(),n=(0,i.getAppEvents)(),l=(0,o.useHistory)(),{url:d}=(0,o.useRouteMatch)(),p=d.split("/types")[0]+"/types",u=t.colors.background.secondary,m=()=>_a((function*(){return Jn().then((e=>e.map((e=>e.thingId))))}))();return(0,a.useEffect)((()=>{}),[e]),r().createElement("div",{className:"row"},r().createElement("div",{className:"col-12 col-md-6 mt-2",style:{height:"100%"}},r().createElement("div",{className:"m-0 mr-md-1",style:{backgroundColor:u,padding:"30px",height:"100%",borderRadius:t.shape.borderRadius()}},r().createElement("h5",null,r().createElement("b",null,"Parents")),r().createElement("hr",null),r().createElement(Ga,{id:e,labels:{id:"Parent",number:"Children number",buttonsText:"parent"},funcGet:()=>_a((function*(){try{const t=yield(a=e,La((function*(){return yield te(`${X}/types/${a}/parent`,{method:"GET"})}))());return Object.entries(null!=t?t:{}).map((([e,t])=>({id:e,num:t})))}catch(e){var t;return 404===e.status||n.publish({type:s.AppEvents.alertError.name,payload:["Error getting the parents: "+(null===(t=e.data)||void 0===t?void 0:t.message)||0]}),[]}var a}))(),funcGetOptions:m,funcUpdate:(t,n)=>_a((function*(){return yield Ma(t,e,n)}))(),funcUnlink:t=>_a((function*(){return yield za(t,e)}))(),resourceRoot:p}))),r().createElement("div",{className:"col-12 col-md-6 mt-2"},r().createElement("div",{className:"m-0 ml-md-1",style:{backgroundColor:u,padding:"30px",height:"100%",borderRadius:t.shape.borderRadius()}},r().createElement("h5",null,r().createElement("b",null,"Children")),r().createElement("hr",null),r().createElement(Ga,{id:e,labels:{id:"Child",number:"Number",buttonsText:"child"},funcGet:()=>_a((function*(){return(t=e,La((function*(){return yield te(`${X}/types/${t}/children`,{method:"GET"})}))()).then((t=>void 0===t?[]:t.map((t=>({id:t.thingId,num:Number(t.attributes._parents[e])})))));var t}))(),funcGetOptions:m,funcUpdate:(t,n)=>_a((function*(){return yield Ma(e,t,n)}))(),funcUnlink:t=>_a((function*(){return yield za(e,t)}))(),resourceRoot:p,onCreate:()=>{l.push(`${p}/${e}/new`)}}))))}var Wa=function(e){return e.information="information",e.hierarchy="hierarchy",e}(Wa||{});function Ja({path:e,id:t,meta:n,section:i}){const l=(0,o.useHistory)(),s=(0,o.useLocation)(),[c,d]=(0,a.useState)(i||"information"),[p,u]=(0,a.useState)({thingId:"",policyId:""}),m=s.pathname.split("/types")[0];(0,a.useEffect)((()=>{i&&i!==c?d(i):i||"information"===c||d("information")}),[i]),(0,a.useEffect)((()=>{Hn(t).then((e=>u(e))).catch((e=>console.error("Error fetching type:",e)))}),[t]);return r().createElement(a.Fragment,null,r().createElement(Zt,{thing:p,isType:!0,sections:Object.values(Wa),selected:c,setSelected:e=>{d(e),l.push(`${m}/types/${t}/${e}`)},funcDelete:Kn}),"hierarchy"===c?r().createElement(Ha,{id:t}):r().createElement(mn,{thingInfo:p,isType:!0}))}const Ka=({meta:e,typeId:t,parentId:n})=>{const[o,i]=(0,a.useState)(),[l,s]=(0,a.useState)(!!t);(0,a.useEffect)((()=>{t&&(s(!0),Hn(t).then((e=>{i(e)})).catch((e=>{console.error("Error fetching type data",e)})).finally((()=>{s(!1)})))}),[t]);const d=(0,a.useCallback)(((e,a,r)=>{if(t)return _n(e,a);if(n){return Ma(n,e,void 0!==r?r:1,a)}return _n(e,a)}),[t,n]);return l?r().createElement("div",{style:{display:"flex",justifyItems:"center",justifyContent:"center",alignContent:"center"}},r().createElement(c.Spinner,{size:20})):r().createElement(ua,{meta:e,thingToEdit:o,parentId:n,isType:!0,funcFromZero:d})};var Va=function(e){return e.List="list",e.Check="check",e.Create="create",e.Edit="edit",e}({});const Ya=({meta:e,pageMode:t="list"})=>{const n=(0,c.useStyles2)(Qa),{id:a,section:l}=(0,o.useParams)(),d="types";return r().createElement(i.PluginPage,{layout:s.PageLayoutType.Canvas},r().createElement("div",{className:n.container},"check"===t?a?r().createElement(Ja,{path:d,id:a,meta:e,section:l}):r().createElement(c.Alert,{title:"Error"},"Type ID is required for check mode."):"create"===t?r().createElement(Ka,{meta:e,parentId:a}):"edit"===t?a?r().createElement(Ka,{meta:e,typeId:a}):r().createElement(c.Alert,{title:"Error"},"Type ID is required for editing."):r().createElement(Aa,{path:d,meta:e})))},Qa=e=>({container:l.css`
    display: flex;
    flex-direction: column;
    gap: ${e.spacing(2)};
    width: 100%;
  `});var Xa=function(e){return e.JSON="JSON",e.YAML="YAML",e}({});const Za=[{label:"JSON",value:"JSON"},{label:"YAML",value:"YAML"}];var er=n(808);function tr(e,t,n,a,r,o,i){try{var l=e[o](i),s=l.value}catch(e){return void n(e)}l.done?t(s):Promise.resolve(s).then(a,r)}function nr(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function ar(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){nr(e,t,n[t])}))}return e}function rr(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const or=e=>{const t=(0,a.useContext)(Ve),n=(0,i.getAppEvents)(),r=(0,o.useHistory)(),{url:l}=(0,o.useRouteMatch)(),[c,d]=(0,a.useState)({id:"",namespace:"",data:"",twins:[],name:""}),[p,u]=(0,a.useState)(Za[0]),[m,f]=(0,a.useState)([]),[y,h]=(0,a.useState)([]),b=void 0!==t.agent_context&&""!==t.agent_context.trim();(0,a.useEffect)((()=>{g().then((e=>{e||(ke.warn("[Auth] User lacks permissions. Redirecting."),r.replace("/"))})),$t().then((e=>{h(e.map((e=>({value:e,label:e}))))})).catch((()=>{n.publish({type:s.AppEvents.alertError.name,payload:["Error getting the identifiers of digital twins"]})}))}),[]),(0,a.useEffect)((()=>{d((e=>rr(ar({},e),{namespace:t.agent_context||""})))}),[t]),(0,a.useEffect)((()=>{e&&!m.some((t=>t.value===e))&&f((t=>[...t,{label:e,value:e}]))}),[e]);return{agent:c,availableTwins:y,selectedTwins:m,setSelectedTwins:f,selectedFormat:p,setSelectedFormat:u,hasSetContext:b,validateString:e=>e.includes(" ")?"Blank spaces are not allowed":e.toLowerCase()!==e?"Uppercase letters are not allowed":e.includes("_")?"Underscores are not allowed":null,handleInputChange:(e,t)=>{const n=e.currentTarget.value;d((e=>rr(ar({},e),{[t]:n})))},handleSubmit:()=>{return(e=function*(){let e={};try{e=p.value===Xa.YAML?er.Ay.load(c.data):JSON.parse(c.data)}catch(e){return void n.publish({type:s.AppEvents.alertError.name,payload:[`Invalid format. Please check your ${p.value} syntax.`]})}var t,a,r;if("Deployment"===e.kind||"CronJob"===e.kind)try{e=yt(e,["metadata","labels","openegiz.agents/name"],c.name);const o=m.map((e=>e.value)).filter((e=>!!e));e=yt(e,["metadata","labels","openegiz.agents/twins"],o),yield(t=c.id,a=c.namespace,r=e,xn((function*(){return yield te(`${Q}/agent/${a}/${t}`,{method:"POST",data:r})}))()),n.publish({type:s.AppEvents.alertSuccess.name,payload:["Agent successfully created"]})}catch(e){console.error(e),n.publish({type:s.AppEvents.alertError.name,payload:["Error creating the agent. Check the definition and network."]})}else n.publish({type:s.AppEvents.alertError.name,payload:["Only Kubernetes 'Deployment' and 'CronJob' are accepted."]})},function(){var t=this,n=arguments;return new Promise((function(a,r){var o=e.apply(t,n);function i(e){tr(o,a,r,i,l,"next",e)}function l(e){tr(o,a,r,i,l,"throw",e)}i(void 0)}))})();var e},goBackToList:()=>{const e=l.split("/agents")[0]+"/agents";r.push(e)}}};function ir(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function lr(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},a=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(a=a.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),a.forEach((function(t){ir(e,t,n[t])}))}return e}function sr(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,a)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}function cr({id:e}){const t=(0,c.useStyles2)(dr),{agent:n,availableTwins:a,selectedTwins:o,setSelectedTwins:i,selectedFormat:l,setSelectedFormat:s,hasSetContext:d,validateString:p,handleInputChange:u,handleSubmit:m,goBackToList:g}=or(e);return r().createElement("div",{className:t.centeredWrapper},r().createElement("div",{className:t.formPanel},r().createElement("div",{className:t.header},r().createElement("h2",null,"Create New Agent"),r().createElement(c.Button,{variant:"secondary",fill:"outline",icon:"arrow-left",onClick:g},"Back to list")),r().createElement(c.Form,{onSubmit:m,className:t.formContainer},(({register:e,errors:m})=>r().createElement(r().Fragment,null,r().createElement(c.Field,{label:"Context",description:"The namespace/grouping for the agent.",required:!0,disabled:d,invalid:!!p(n.namespace),error:p(n.namespace)||""},r().createElement(c.Input,sr(lr({},e("namespace",{required:!d})),{value:n.namespace,onChange:e=>u(e,"namespace"),placeholder:"e.g. production-floor"}))),r().createElement(c.Field,{label:"Identifier",description:"Unique identifier for the agent (lowercase, no spaces).",required:!0,invalid:!!p(n.id),error:p(n.id)||""},r().createElement(c.Input,sr(lr({},e("id",{required:!0})),{value:n.id,onChange:e=>u(e,"id"),placeholder:"e.g. agent-001"}))),r().createElement(c.Field,{label:"Name",description:"Readable name (no spaces allowed).",required:!0,invalid:n.name.includes(" "),error:n.name.includes(" ")?"Blank spaces are not allowed":""},r().createElement(c.Input,sr(lr({},e("name",{required:!0})),{value:n.name,onChange:e=>u(e,"name"),placeholder:"e.g. MyAgent"}))),r().createElement(c.Field,{label:"Related Digital Twins",description:"Optional: Link this agent to specific digital twins."},r().createElement(c.MultiSelect,{options:a,value:o,onChange:i,placeholder:"Select twins..."})),r().createElement("div",{className:t.editorSection},r().createElement(c.Field,{label:"Definition Format",description:"Choose the format for your Kubernetes definition."},r().createElement(c.RadioButtonGroup,{options:Za,value:l.value,onChange:e=>s({label:e,value:e})})),r().createElement(c.Field,{label:"Kubernetes Definition",description:"Deployment or CronJob definition.",required:!0,className:t.flexField},r().createElement(c.TextArea,sr(lr({},e("data",{required:!0})),{value:n.data,onChange:e=>u(e,"data"),className:t.textArea,placeholder:`Paste your ${l.value} here...`})))),r().createElement("div",{className:t.buttonGroup},r().createElement(c.Button,{variant:"primary",type:"submit"},"Create Agent")))))))}const dr=e=>({centeredWrapper:l.css`
        display: flex;
        justify-content: center;
        width: 100%;
        padding-bottom: ${e.spacing(4)};
    `,formPanel:l.css`
        background-color: ${e.colors.background.primary};
        border: 1px solid ${e.colors.border.weak};
        border-radius: ${e.shape.borderRadius()};
        padding: ${e.spacing(4)};
        box-shadow: ${e.shadows.z1};
        width: 100%;
        max-width: 900px;
        display: flex;
        flex-direction: column;
    `,header:l.css`
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: ${e.spacing(3)};
        border-bottom: 1px solid ${e.colors.border.weak};
        padding-bottom: ${e.spacing(2)};
        
        h2 {
            margin: 0;
            font-size: ${e.typography.h3.fontSize};
        }
    `,formContainer:l.css`
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    `,editorSection:l.css`
        margin-top: ${e.spacing(2)};
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    `,flexField:l.css`
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    `,textArea:l.css`
        font-family: ${e.typography.fontFamilyMonospace};
        min-height: 400px;
        resize: vertical;
    `,buttonGroup:l.css`
        display: flex;
        justify-content: flex-end;
        gap: ${e.spacing(2)};
        margin-top: ${e.spacing(4)};
        padding-top: ${e.spacing(2)};
        border-top: 1px solid ${e.colors.border.weak};
    `});var pr=function(e){return e.List="list",e.Create="create",e}({});const ur=({meta:e,pageMode:t="list"})=>{const n=(0,c.useStyles2)(mr),{id:l}=(0,o.useParams)(),d=(0,a.useMemo)((()=>Qe(e)),[e]);return r().createElement(i.PluginPage,{layout:s.PageLayoutType.Canvas},r().createElement("div",{className:n.container},r().createElement(Ve.Provider,{value:d},"create"===t?r().createElement(cr,{id:l}):r().createElement(zn,null))))},mr=e=>({container:l.css`
    display: flex;
    flex-direction: column;
    gap: ${e.spacing(2)};
    width: 100%;
    `}),gr=n.p+"f0ed8345a9f2df7d8f07.svg",fr={label:"Agents",id:"agents",icon:"users-alt"},yr=[{label:"Connections",id:"connections",icon:"plug"},{label:"Policies",id:"policies",icon:"shield"}],hr=[{label:"Twins",id:"twins",icon:"cube"},{label:"Types",id:"types",icon:"sitemap"}],br=({basePath:e,meta:t})=>{const n=(0,c.useStyles2)(vr),i=(0,o.useLocation)(),l=(0,o.useHistory)(),[s,d]=(0,a.useState)("twins");let p=[...hr];if(t.jsonData&&t.jsonData.agentsURL&&""!==t.jsonData.agentsURL.trim())try{new URL(t.jsonData.agentsURL),p.push(fr)}catch(e){}yr.forEach((e=>p.push(e))),(0,a.useEffect)((()=>{const t=i.pathname.replace(e,"").split("/")[1],n=p.find((e=>e.id===t));d(n?n.id:"twins")}),[i.pathname,e]);return r().createElement("header",{className:n.header},r().createElement("div",{className:n.logoSection},r().createElement("div",{className:n.logoContainer},r().createElement("img",{src:gr,alt:"OpenEgiz Logo",className:n.logoImage})),r().createElement("h1",{className:n.appName},"OpenEgiz")),r().createElement("div",{className:n.navSection},r().createElement(c.TabsBar,{className:n.tabsBar,hideBorder:!0},p.map((t=>r().createElement(c.Tab,{key:t.id,label:t.label,icon:t.icon,active:s===t.id,onChangeTab:()=>{return n=t.id,void l.push(`${e}/${n}`);var n},className:n.tabItem}))))))},vr=e=>({header:l.css`
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 56px;
    padding: 0 ${e.spacing(2)};
    background: ${e.colors.background.primary}; 
    border-bottom: 1px solid ${e.colors.border.weak};
    flex-shrink: 0;
    width: 100%;
    box-sizing: border-box;
    overflow-x: hidden;
    position: sticky; /* Hace que se pegue al hacer scroll */
    top: 40px;           /* Indica que se pegue al borde superior */
    z-index: 1000;    /* Asegura que flote sobre tablas o gráficos */
  `,logoSection:l.css`
    display: flex;
    align-items: center;
    gap: ${e.spacing(1.5)};
    flex-shrink: 0;
  `,logoContainer:l.css`
     display: flex;
     align-items: center;
     justify-content: center;
     background: ${e.colors.background.primary};
     padding: 8px;
     border-radius: ${e.shape.borderRadius()};
     box-shadow: ${e.shadows.z1};
  `,logoImage:l.css`
    height: 24px; 
    width: auto; 
    display: block; 
  `,appName:l.css`
    margin: 0;
    font-size: 18px;
    font-weight: ${e.typography.fontWeightMedium};
    color: ${e.colors.text.primary};
    line-height: 1;
    letter-spacing: -0.01em;
    white-space: nowrap;
  `,navSection:l.css`
    height: 100%;
    display: flex;
    align-items: flex-end;
    flex-grow: 1;       
    min-width: 0;      
    justify-content: flex-end;
  `,tabsBar:l.css`
    margin-bottom: 0 !important; 
    border-bottom: none !important;
    max-width: 100%; 
    overflow-x: auto; 
    &::-webkit-scrollbar { display: none; }
    scrollbar-width: none;
  `,tabItem:l.css`
    padding-top: ${e.spacing(1.5)} !important;
    padding-bottom: ${e.spacing(1)} !important;
    margin-bottom: -1px;
    white-space: nowrap;
  `}),Er=({meta:e})=>{const t=`/a/${e.id}`,n=(0,a.useMemo)((()=>{var t;const n=null===(t=e.jsonData)||void 0===t?void 0:t.agentsURL;if(!n)return!1;try{return new URL(n),!0}catch(e){return!1}}),[e.jsonData]);return r().createElement("div",{style:{display:"flex",flexDirection:"column",height:"100vh"}},r().createElement(br,{basePath:t,meta:e}),r().createElement(o.Switch,null,r().createElement(o.Route,{path:`${t}/connections/new`,render:()=>r().createElement(We,{meta:e,pageMode:He.Create})}),r().createElement(o.Route,{path:`${t}/connections/:id/edit`,render:()=>r().createElement(We,{meta:e,pageMode:He.Edit})}),r().createElement(o.Route,{path:`${t}/connections`,render:()=>r().createElement(We,{meta:e,pageMode:He.List})}),r().createElement(o.Route,{path:`${t}/twins/new`,render:()=>r().createElement(Oa,{meta:e,pageMode:xa.Create,elementType:$a.Twin})}),r().createElement(o.Route,{path:`${t}/twins/:id/simulations/new`,render:()=>r().createElement(Oa,{meta:e,pageMode:xa.Create,elementType:$a.Simulation})}),r().createElement(o.Route,{path:`${t}/twins/:id/simulations/:simulationId/edit`,render:()=>r().createElement(Oa,{meta:e,pageMode:xa.Edit,elementType:$a.Simulation})}),n&&r().createElement(o.Route,{path:`${t}/twins/:id/agents/new`,render:()=>r().createElement(ur,{meta:e,pageMode:pr.Create})}),r().createElement(o.Route,{path:`${t}/twins/:id/new`,render:()=>r().createElement(Oa,{meta:e,pageMode:xa.Create,elementType:$a.Twin})}),r().createElement(o.Route,{path:`${t}/twins/:id/edit`,render:()=>r().createElement(Oa,{meta:e,pageMode:xa.Edit,elementType:$a.Twin})}),r().createElement(o.Route,{path:`${t}/twins/:id/copy`,render:()=>r().createElement(Oa,{meta:e,pageMode:xa.Copy,elementType:$a.Twin})}),r().createElement(o.Route,{path:`${t}/twins/:id/:section`,render:()=>r().createElement(Oa,{meta:e,pageMode:xa.Check,elementType:$a.Twin})}),r().createElement(o.Route,{path:`${t}/twins/:id`,render:()=>r().createElement(Oa,{meta:e,pageMode:xa.Check,elementType:$a.Twin})}),r().createElement(o.Route,{path:`${t}/twins`,render:()=>r().createElement(Oa,{meta:e,pageMode:xa.List})}),r().createElement(o.Route,{path:`${t}/types/new`,render:()=>r().createElement(Ya,{meta:e,pageMode:Va.Create})}),r().createElement(o.Route,{path:`${t}/types/:id/new`,render:()=>r().createElement(Ya,{meta:e,pageMode:Va.Create})}),r().createElement(o.Route,{path:`${t}/types/:id/edit`,render:()=>r().createElement(Ya,{meta:e,pageMode:Va.Edit})}),r().createElement(o.Route,{path:`${t}/types/:id/:section`,render:()=>r().createElement(Ya,{meta:e,pageMode:Va.Check})}),r().createElement(o.Route,{path:`${t}/types/:id`,render:()=>r().createElement(Ya,{meta:e,pageMode:Va.Check})}),r().createElement(o.Route,{path:`${t}/types`,render:()=>r().createElement(Ya,{meta:e,pageMode:Va.List})}),r().createElement(o.Route,{path:`${t}/policies`,render:()=>r().createElement(Ia,{pageMode:ja.List})}),n&&r().createElement(o.Route,{path:`${t}/agents/new`,render:()=>r().createElement(ur,{meta:e,pageMode:pr.Create})}),n&&r().createElement(o.Route,{path:`${t}/agents`,render:()=>r().createElement(ur,{meta:e,pageMode:pr.List})}),r().createElement(o.Route,{exact:!0,path:t,render:()=>r().createElement(Oa,{meta:e})}),r().createElement(o.Route,{render:()=>r().createElement(i.PluginPage,null,r().createElement("div",{className:"page-center"},r().createElement("h3",null,"Page not found")))})))},wr=Er}}]);
//# sourceMappingURL=187.js.map?_cache=a582f4a36dcd5086a830